# JHON - Hotel Test (prueba de juego FPS para Android)

Prueba tecnica de un shooter en primera persona con zombis para Android (libGDX + OpenGL ES 2.0).
Todo el contenido es original y se genera por codigo: no hay modelos, texturas ni sonidos externos.

## Como generar el APK
1. Instala **Android Studio** (Hedgehog o mas nuevo) con Android SDK 34.
2. `File > Open` y elige esta carpeta (`JhonHotelTest`). Espera a que termine el Gradle Sync
   (necesita internet la primera vez para bajar libGDX 1.12.1 y el plugin de Android).
3. `Build > Build Bundle(s) / APK(s) > Build APK(s)`  -> `android/build/outputs/apk/debug/android-debug.apk`
   (o conecta el telefono con depuracion USB y pulsa Run).

Por linea de comandos: `./gradlew :android:assembleDebug` (define `ANDROID_HOME` o crea `local.properties` con `sdk.dir=...`).

## Que incluye
- **Jhon**, sobreviviente en primera persona, con intro cinematica: el helicoptero despega de la azotea sin el.
- **Hotel Mirador** (diseno propio): azotea con helipad -> escalera -> piso 1 (pasillo y 7 cuartos) -> escalera -> lobby con recepcion -> calle.
- **Armas**: pistola 9mm, AK-47, escopeta y hacha de bombero (todas en primera persona, con retroceso, recarga y animaciones).
- **Zombis**: caminante, corredor y bruto. Detectan por vista y ruido, suben/bajan escaleras, maximo 50 vivos a la vez.
- **Evento final**: activa la alarma en la recepcion, resiste la horda y corre al helicoptero que aterriza en la calle.
- Iluminacion por pixel (luces puntuales que parpadean, linterna, niebla), particulas, sonido 3D generado por codigo.

## Controles tactiles
- Mitad izquierda: joystick flotante (mover). Resto de la pantalla: arrastrar para mirar.
- FUEGO, SALTO, RECARGA, USAR (alarma), LUZ (linterna) y slots 1-4 (pistola, AK, escopeta, hacha).
- Las armas se recogen por el nivel: hacha en la casa de escaleras de la azotea, AK en un cuarto del piso 1 (sur), escopeta detras de la recepcion.

## Ajustes rapidos (si va lento o quieres mas zombis)
- `Game.java`: `MAX_ZOMBIES` (50), `RENDER_SCALE` (0.8; baja a 0.6 en telefonos lentos), `HORDE_TIME`.
- `Gfx.java`: `NL` = luces puntuales por pixel (6; baja a 4).

## Estructura
- `core/` logica del juego (Java puro + libGDX): `Game`, `Level`, `Hotel` (mapa), `Zombie`, `Weapons`, `Hud`, `Gfx`, `Tex`, `Sfx`.
- `android/` solo el lanzador y el manifiesto (orientacion horizontal, pantalla completa).

## Estado
Prueba experimental. El codigo se reviso y se simulo el recorrido del nivel por codigo, pero **no se ha compilado con libGDX real ni probado en un telefono**:
es posible que haya que corregir algun error de compilacion o ajustar rendimiento/controles en tu dispositivo.
