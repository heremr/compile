package com.jhon.test;

import com.badlogic.gdx.ApplicationAdapter;

/** Punto de entrada de libGDX: delega todo en Game. */
public class JhonGame extends ApplicationAdapter {
    Game game;

    @Override
    public void create() {
        game = new Game();
    }

    @Override
    public void resize(int width, int height) {
        if (game != null) game.resize(width, height);
    }

    @Override
    public void render() {
        game.frame();
    }

    @Override
    public void dispose() {
        if (game != null) game.dispose();
    }
}
