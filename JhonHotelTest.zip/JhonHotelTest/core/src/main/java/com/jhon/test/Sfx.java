package com.jhon.test;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.audio.Sound;
import com.badlogic.gdx.files.FileHandle;

import java.util.Random;

/** Sonidos generados por codigo (se escriben como WAV en el almacenamiento local al primer arranque). */
public class Sfx {
    static final int SR = 22050;
    static final Random R = new Random(1234);

    public static Sound pistol, ak, shotgun, reload, empty, swing, hit, hurt, pickup, alarm, heli, wind, alert;
    public static Sound[] groan = new Sound[3];
    public static Sound[] step = new Sound[2];

    // posicion/orientacion del oyente (la actualiza el juego cada frame)
    public static float lx, ly, lz, rx, rz;

    static float[] buf(float sec) { return new float[(int) (sec * SR)]; }
    static float nz() { return R.nextFloat() * 2f - 1f; }
    static float ex(float t, float k) { return (float) Math.exp(-t * k); }
    static float sn(float f, float t) { return (float) Math.sin(6.2831853f * f * t); }

    static Sound save(String name, float[] d, float gain) {
        float peak = 0.0001f;
        for (float v : d) peak = Math.max(peak, Math.abs(v));
        float k = gain * 0.95f / peak;
        byte[] b = new byte[44 + d.length * 2];
        int dataLen = d.length * 2;
        putStr(b, 0, "RIFF"); putInt(b, 4, 36 + dataLen); putStr(b, 8, "WAVE");
        putStr(b, 12, "fmt "); putInt(b, 16, 16); putShort(b, 20, 1); putShort(b, 22, 1);
        putInt(b, 24, SR); putInt(b, 28, SR * 2); putShort(b, 32, 2); putShort(b, 34, 16);
        putStr(b, 36, "data"); putInt(b, 40, dataLen);
        for (int i = 0; i < d.length; i++) {
            float v = Math.max(-1f, Math.min(1f, d[i] * k));
            putShort(b, 44 + i * 2, (int) (v * 32000));
        }
        FileHandle fh = Gdx.files.local("sfx/" + name + ".wav");
        fh.writeBytes(b, false);
        return Gdx.audio.newSound(fh);
    }

    static void putStr(byte[] b, int o, String s) { for (int i = 0; i < s.length(); i++) b[o + i] = (byte) s.charAt(i); }
    static void putInt(byte[] b, int o, int v) { b[o] = (byte) v; b[o + 1] = (byte) (v >> 8); b[o + 2] = (byte) (v >> 16); b[o + 3] = (byte) (v >> 24); }
    static void putShort(byte[] b, int o, int v) { b[o] = (byte) v; b[o + 1] = (byte) (v >> 8); }

    static float[] gun(float len, float crackK, float thumpF, float thumpK, float tailK, float tailA, float tailMix) {
        float[] d = buf(len);
        float lp = 0;
        for (int i = 0; i < d.length; i++) {
            float t = i / (float) SR;
            float n = nz();
            lp += tailA * (n - lp);
            d[i] = n * ex(t, crackK) + sn(thumpF, t) * ex(t, thumpK) * 0.9f + lp * ex(t, tailK) * tailMix;
        }
        return d;
    }

    static float[] groan(float f0, float dur) {
        float[] d = buf(dur);
        float ph = 0, y = 0, br = 0;
        for (int i = 0; i < d.length; i++) {
            float t = i / (float) SR;
            float f = f0 * (1f + 0.10f * sn(5f, t)) * (1f - 0.25f * t / dur);
            ph += f / SR;
            ph -= (float) Math.floor(ph);
            float saw = ph * 2f - 1f;
            y += 0.10f * (saw - y);
            br += 0.2f * (nz() - br);
            float env = Math.min(t / 0.12f, 1f) * Math.min((dur - t) / 0.35f, 1f) * (0.7f + 0.3f * sn(3f, t));
            d[i] = (y * 1.6f + br * 0.5f) * env;
        }
        return d;
    }

    public static void init() {
        Sfx.pistol = save("pistol", gun(0.35f, 40, 110, 22, 9, 0.2f, 0.35f), 0.9f);
        Sfx.ak = save("ak", gun(0.40f, 30, 80, 16, 7, 0.2f, 0.4f), 1.0f);
        Sfx.shotgun = save("shotgun", gun(0.75f, 16, 55, 9, 4, 0.15f, 0.6f), 1.0f);

        float[] d = buf(0.85f);
        for (int i = 0; i < d.length; i++) {
            float t = i / (float) SR;
            float v = 0;
            if (t < 0.05f) v += nz() * ex(t, 90) * 0.9f;
            if (t > 0.30f && t < 0.40f) v += nz() * ex(t - 0.30f, 50) * 0.5f;
            if (t > 0.55f && t < 0.62f) v += nz() * ex(t - 0.55f, 110) * 1.0f;
            d[i] = v;
        }
        reload = save("reload", d, 0.6f);

        d = buf(0.12f);
        for (int i = 0; i < d.length; i++) { float t = i / (float) SR; d[i] = nz() * ex(t, 90) * (t < 0.03f ? 1f : 0.4f); }
        empty = save("empty", d, 0.5f);

        d = buf(0.42f);
        float lp = 0;
        for (int i = 0; i < d.length; i++) {
            float t = i / (float) SR;
            lp += (0.05f + 0.30f * t / 0.42f) * (nz() - lp);
            float s = sn(0.5f / 0.42f, t);
            d[i] = lp * s * s;
        }
        swing = save("swing", d, 0.7f);

        d = buf(0.22f);
        lp = 0;
        for (int i = 0; i < d.length; i++) {
            float t = i / (float) SR;
            lp += 0.15f * (nz() - lp);
            d[i] = lp * ex(t, 22) * 1.5f + sn(70, t) * ex(t, 28);
        }
        hit = save("hit", d, 0.9f);

        groan[0] = save("groan0", groan(95, 1.3f), 0.8f);
        groan[1] = save("groan1", groan(120, 1.0f), 0.8f);
        groan[2] = save("groan2", groan(75, 1.6f), 0.8f);

        d = buf(0.35f);
        float ph = 0, y = 0;
        for (int i = 0; i < d.length; i++) {
            float t = i / (float) SR;
            ph += (190f - 90f * t) / SR;
            ph -= (float) Math.floor(ph);
            y += 0.2f * ((ph * 2f - 1f) - y);
            d[i] = (y + nz() * 0.15f) * ex(t, 7);
        }
        hurt = save("hurt", d, 0.8f);

        for (int k = 0; k < 2; k++) {
            d = buf(0.16f);
            lp = 0;
            for (int i = 0; i < d.length; i++) {
                float t = i / (float) SR;
                lp += (0.07f + 0.02f * k) * (nz() - lp);
                d[i] = lp * ex(t, 35);
            }
            step[k] = save("step" + k, d, 0.5f);
        }

        d = buf(2.0f); // helicoptero: pulso de palas a 13 Hz (26 ciclos = loop limpio)
        lp = 0;
        for (int i = 0; i < d.length; i++) {
            float t = i / (float) SR;
            lp += 0.22f * (nz() - lp);
            float p = 0.5f + 0.5f * sn(13f, t);
            p = p * p * p;
            d[i] = lp * p * 1.4f + sn(72f, t) * 0.25f + sn(144f, t) * 0.1f * p;
        }
        heli = save("heli", d, 0.9f);

        d = buf(4.0f);
        lp = 0;
        for (int i = 0; i < d.length; i++) {
            float t = i / (float) SR;
            lp += 0.03f * (nz() - lp);
            d[i] = lp * (0.65f + 0.35f * sn(0.25f, t) + 0.15f * sn(0.75f, t));
        }
        wind = save("wind", d, 0.5f);

        d = buf(2.0f);
        for (int i = 0; i < d.length; i++) {
            float t = i / (float) SR;
            float f = ((int) (t * 2f)) % 2 == 0 ? 780f : 1020f;
            float s = sn(f, t);
            d[i] = (s > 0 ? 1f : -1f) * 0.35f + s * 0.4f;
        }
        alarm = save("alarm", d, 0.5f);

        d = buf(0.28f);
        for (int i = 0; i < d.length; i++) {
            float t = i / (float) SR;
            float f = t < 0.12f ? 880f : 1320f;
            d[i] = sn(f, t) * ex(t, 9) * 0.8f;
        }
        pickup = save("pickup", d, 0.6f);

        d = buf(0.6f);
        for (int i = 0; i < d.length; i++) {
            float t = i / (float) SR;
            d[i] = (sn(220f, t) + 0.6f * sn(233f, t)) * ex(t, 5) * 0.6f;
        }
        alert = save("alert", d, 0.5f);
    }

    // ---------------------------------------------------------------- reproduccion

    public static void play2d(Sound s, float vol) {
        if (s != null) s.play(vol);
    }

    public static void playAt(Sound s, float x, float y, float z, float vol, float pitch) {
        if (s == null) return;
        float dx = x - lx, dy = y - ly, dz = z - lz;
        float d = (float) Math.sqrt(dx * dx + dy * dy + dz * dz) + 0.01f;
        float v = vol / (1f + d * 0.10f);
        if (v < 0.02f) return;
        float pan = Math.max(-1f, Math.min(1f, (dx * rx + dz * rz) / d));
        s.play(Math.min(1f, v), pitch, pan);
    }

    public static float pitchVar(float amount) {
        return 1f + (R.nextFloat() * 2f - 1f) * amount;
    }
}
