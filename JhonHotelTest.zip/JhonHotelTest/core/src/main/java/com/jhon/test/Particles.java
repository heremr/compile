package com.jhon.test;

/** Particulas simples: chispas de impacto, sangre, casquillos. */
public class Particles {
    static final int MAX = 260;
    final float[] px = new float[MAX], py = new float[MAX], pz = new float[MAX];
    final float[] vx = new float[MAX], vy = new float[MAX], vz = new float[MAX];
    final float[] life = new float[MAX], size = new float[MAX], fl = new float[MAX];
    final float[] cr = new float[MAX], cg = new float[MAX], cb = new float[MAX];
    final boolean[] glow = new boolean[MAX];
    int next = 0;

    public void emit(Level L, float x, float y, float z, float dx, float dy, float dz,
                     float lifeT, float sz, float r, float g, float b, boolean glowing) {
        int i = next;
        next = (next + 1) % MAX;
        px[i] = x; py[i] = y; pz[i] = z;
        vx[i] = dx; vy[i] = dy; vz[i] = dz;
        life[i] = lifeT; size[i] = sz;
        cr[i] = r; cg[i] = g; cb[i] = b;
        glow[i] = glowing;
        float gnd = L.groundAt(x, y + 0.5f, z, 0.05f);
        fl[i] = gnd < -50f ? -100f : gnd;
    }

    public void blood(Level L, float x, float y, float z, float nx, float ny, float nz, int n) {
        for (int i = 0; i < n; i++) {
            emit(L, x, y, z, nx * 2f + Util.rnd(-1.5f, 1.5f), ny * 2f + Util.rnd(0f, 2.5f), nz * 2f + Util.rnd(-1.5f, 1.5f),
                    Util.rnd(0.4f, 0.9f), Util.rnd(0.03f, 0.07f), Util.rnd(0.35f, 0.6f), 0.02f, 0.02f, false);
        }
    }

    public void sparks(Level L, float x, float y, float z, float nx, float ny, float nz, int n) {
        for (int i = 0; i < n; i++) {
            emit(L, x, y, z, nx * 3f + Util.rnd(-2f, 2f), ny * 3f + Util.rnd(0f, 2f), nz * 3f + Util.rnd(-2f, 2f),
                    Util.rnd(0.15f, 0.4f), 0.025f, 1f, 0.8f, 0.4f, true);
        }
    }

    public void update(float dt) {
        for (int i = 0; i < MAX; i++) {
            if (life[i] <= 0f) continue;
            life[i] -= dt;
            vy[i] -= 12f * dt;
            px[i] += vx[i] * dt;
            py[i] += vy[i] * dt;
            pz[i] += vz[i] * dt;
            if (py[i] <= fl[i] + 0.01f) {
                py[i] = fl[i] + 0.01f;
                vx[i] = 0f; vy[i] = 0f; vz[i] = 0f;
            }
        }
    }

    public void draw() {
        Gfx.setTex(null);
        for (int i = 0; i < MAX; i++) {
            if (life[i] <= 0f) continue;
            float s = size[i];
            if (glow[i]) {
                Gfx.setColor(0f, 0f, 0f);
                Gfx.setEmis(cr[i], cg[i], cb[i]);
            } else {
                Gfx.setColor(cr[i], cg[i], cb[i]);
                Gfx.setEmis(0f, 0f, 0f);
            }
            Gfx.worldBox(px[i], py[i], pz[i], s, s, s);
        }
        Gfx.setEmis(0f, 0f, 0f);
    }
}
