package com.jhon.test;

import com.badlogic.gdx.graphics.Mesh;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g3d.utils.MeshBuilder;

import java.util.ArrayList;

/** Contenedor del nivel: geometria estatica (mallas por material), colisiones, luces, items y puntos de aparicion. */
public class Level {
    public static final float TH = 0.3f;      // grosor de muros
    public static final float STEP = 0.55f;   // altura maxima que se sube caminando

    // materiales
    public static final int WALL = 0, CARPET = 1, TILE = 2, CEIL = 3, CONC = 4, ASPH = 5, METAL = 6, WOOD = 7,
            GLASS = 8, FABRIC1 = 9, FABRIC2 = 10, BLACK = 11, LAMP = 12, RED = 13, YELLOW = 14, WHITE = 15,
            GREEN = 16, BLOOD = 17, ROOFTOP = 18, CARRED = 19, CARBLUE = 20, CARGREY = 21, LITWIN = 22,
            DARKCONC = 23, PADDARK = 24, AMBER = 25, NMAT = 26;

    public static class Box {
        public final float x0, y0, z0, x1, y1, z1;
        Box(float x0, float y0, float z0, float x1, float y1, float z1) {
            this.x0 = x0; this.y0 = y0; this.z0 = z0; this.x1 = x1; this.y1 = y1; this.z1 = z1;
        }
    }

    /** mode: 0 fija, 1 parpadeo electrico, 2 baliza lenta (roja), 3 apagada */
    public static class Light {
        public float x, y, z, r, g, b, rad;
        public int mode;
        public float phase;
        public float cur = 1f;
    }

    /** type: 0 botiquin, 1 municion, 2 AK, 3 escopeta, 4 hacha */
    public static class Pickup {
        public int type;
        public float x, y, z;
        public boolean taken;
    }

    /** type: 0 caminante, 1 corredor, 2 bruto */
    public static class Spawn {
        public float x, y, z;
        public int type;
    }

    static class Mat {
        Texture tex;
        float r, g, b, er, eg, eb, tile;
        final Gfx.MeshSet set = new Gfx.MeshSet();
    }

    final Mat[] mats = new Mat[NMAT];
    public final ArrayList<Box> solids = new ArrayList<Box>();
    public final ArrayList<Light> lights = new ArrayList<Light>();
    public final ArrayList<Pickup> pickups = new ArrayList<Pickup>();
    public final ArrayList<Spawn> idleSpawns = new ArrayList<Spawn>();
    public final ArrayList<float[]> hordeSpawns = new ArrayList<float[]>();

    public float startX, startY, startZ, startYaw;
    public float alarmX, alarmY, alarmZ;
    public float lzX, lzZ;       // zona de aterrizaje del helicoptero de rescate
    public float padX, padY, padZ; // helipad del techo

    // texturas compartidas con el resto del juego
    public Texture tGrain, tMetal, tWood;

    public Level() {
        Texture wall = Tex.wallpaper(), carpet = Tex.carpet(), tile = Tex.tile(), ceil = Tex.ceiling();
        Texture conc = Tex.concrete(), asph = Tex.asphalt(), metal = Tex.metal(), wood = Tex.wood();
        tGrain = Tex.grain();
        tMetal = metal;
        tWood = wood;
        def(WALL, wall, 1, 1, 1, 0, 0, 0, 3f);
        def(CARPET, carpet, 1, 1, 1, 0, 0, 0, 3f);
        def(TILE, tile, 1, 1, 1, 0, 0, 0, 4f);
        def(CEIL, ceil, 1, 1, 1, 0, 0, 0, 4f);
        def(CONC, conc, 0.85f, 0.85f, 0.85f, 0, 0, 0, 4f);
        def(ASPH, asph, 1, 1, 1, 0, 0, 0, 6f);
        def(METAL, metal, 0.9f, 0.9f, 0.95f, 0, 0, 0, 2f);
        def(WOOD, wood, 1, 1, 1, 0, 0, 0, 2f);
        def(GLASS, null, 0.05f, 0.07f, 0.12f, 0.05f, 0.09f, 0.17f, 1f);
        def(FABRIC1, tGrain, 0.34f, 0.10f, 0.09f, 0, 0, 0, 1f);
        def(FABRIC2, tGrain, 0.12f, 0.22f, 0.27f, 0, 0, 0, 1f);
        def(BLACK, tGrain, 0.05f, 0.05f, 0.05f, 0, 0, 0, 1f);
        def(LAMP, null, 0, 0, 0, 1.0f, 0.92f, 0.7f, 1f);
        def(RED, null, 0.7f, 0.05f, 0.05f, 0.8f, 0.05f, 0.05f, 1f);
        def(YELLOW, null, 0.8f, 0.68f, 0.1f, 0, 0, 0, 1f);
        def(WHITE, tGrain, 0.8f, 0.8f, 0.78f, 0, 0, 0, 1f);
        def(GREEN, tGrain, 0.15f, 0.35f, 0.12f, 0, 0, 0, 1f);
        def(BLOOD, null, 0.22f, 0.01f, 0.01f, 0, 0, 0, 1f);
        def(ROOFTOP, asph, 1.5f, 1.5f, 1.55f, 0, 0, 0, 6f);
        def(CARRED, tGrain, 0.40f, 0.04f, 0.04f, 0, 0, 0, 1f);
        def(CARBLUE, tGrain, 0.07f, 0.12f, 0.30f, 0, 0, 0, 1f);
        def(CARGREY, tGrain, 0.25f, 0.25f, 0.27f, 0, 0, 0, 1f);
        def(LITWIN, null, 0, 0, 0, 0.9f, 0.7f, 0.35f, 1f);
        def(DARKCONC, conc, 0.32f, 0.34f, 0.38f, 0, 0, 0, 6f);
        def(PADDARK, null, 0.07f, 0.07f, 0.08f, 0, 0, 0, 1f);
        def(AMBER, null, 0, 0, 0, 1.0f, 0.6f, 0.1f, 1f);

        Hotel.build(this);

        for (int i = 0; i < NMAT; i++) mats[i].set.finish();
    }

    void def(int id, Texture t, float r, float g, float b, float er, float eg, float eb, float tile) {
        Mat m = new Mat();
        m.tex = t; m.r = r; m.g = g; m.b = b; m.er = er; m.eg = eg; m.eb = eb; m.tile = tile;
        mats[id] = m;
    }

    // ------------------------------------------------------------------ construccion

    /** Caja con material por cara (-1 = sin esa cara). */
    public Box box(int mt, int mb, int ms, float x0, float y0, float z0, float x1, float y1, float z1, boolean solid) {
        float ax = Math.min(x0, x1), bx = Math.max(x0, x1);
        float ay = Math.min(y0, y1), by = Math.max(y0, y1);
        float az = Math.min(z0, z1), bz = Math.max(z0, z1);
        MeshBuilder top = mt < 0 ? null : mats[mt].set.b();
        MeshBuilder bot = mb < 0 ? null : mats[mb].set.b();
        MeshBuilder side = ms < 0 ? null : mats[ms].set.b();
        Gfx.boxFaces(top, bot, side, ax, ay, az, bx, by, bz,
                mt < 0 ? 1f : mats[mt].tile, mb < 0 ? 1f : mats[mb].tile, ms < 0 ? 1f : mats[ms].tile);
        Box b = null;
        if (solid) {
            b = new Box(ax, ay, az, bx, by, bz);
            solids.add(b);
        }
        return b;
    }

    public Box b(int m, float x0, float y0, float z0, float x1, float y1, float z1) {
        return box(m, m, m, x0, y0, z0, x1, y1, z1, true);
    }

    public Box nb(int m, float x0, float y0, float z0, float x1, float y1, float z1) {
        return box(m, m, m, x0, y0, z0, x1, y1, z1, false);
    }

    /** Muro a lo largo de X en la linea z. clad>=0: revestimiento interior con ese material hacia 'inward' (+1/-1). */
    public void wx(int m, int clad, float inward, float z, float xa, float xb, float ya, float yb) {
        if (xb - xa < 0.01f || yb - ya < 0.01f) return;
        box(m, m, m, xa, ya, z - TH / 2, xb, yb, z + TH / 2, true);
        if (clad >= 0) {
            float zz = z + inward * (TH / 2 + 0.015f);
            box(-1, -1, clad, xa, ya, zz - 0.015f, xb, yb, zz + 0.015f, false);
        }
    }

    public void wz(int m, int clad, float inward, float x, float za, float zb, float ya, float yb) {
        if (zb - za < 0.01f || yb - ya < 0.01f) return;
        box(m, m, m, x - TH / 2, ya, za, x + TH / 2, yb, zb, true);
        if (clad >= 0) {
            float xx = x + inward * (TH / 2 + 0.015f);
            box(-1, -1, clad, xx - 0.015f, ya, za, xx + 0.015f, yb, zb, false);
        }
    }

    /** ops: {inicio, fin, alturaInferior, alturaSuperior} ordenadas. Si glass, las ventanas (alturaInferior>ya) llevan vidrio. */
    public void wxo(int m, int clad, float inward, float z, float xa, float xb, float ya, float yb, float[][] ops, boolean glass) {
        float cur = xa;
        for (float[] o : ops) {
            wx(m, clad, inward, z, cur, o[0], ya, yb);
            wx(m, clad, inward, z, o[0], o[1], ya, o[2]);
            wx(m, clad, inward, z, o[0], o[1], o[3], yb);
            if (glass && o[2] > ya && o[3] < yb) box(GLASS, GLASS, GLASS, o[0], o[2], z - 0.03f, o[1], o[3], z + 0.03f, true);
            cur = o[1];
        }
        wx(m, clad, inward, z, cur, xb, ya, yb);
    }

    public void wzo(int m, int clad, float inward, float x, float za, float zb, float ya, float yb, float[][] ops, boolean glass) {
        float cur = za;
        for (float[] o : ops) {
            wz(m, clad, inward, x, cur, o[0], ya, yb);
            wz(m, clad, inward, x, o[0], o[1], ya, o[2]);
            wz(m, clad, inward, x, o[0], o[1], o[3], yb);
            if (glass && o[2] > ya && o[3] < yb) box(GLASS, GLASS, GLASS, x - 0.03f, o[2], o[0], x + 0.03f, o[3], o[1], true);
            cur = o[1];
        }
        wz(m, clad, inward, x, cur, zb, ya, yb);
    }

    /** Losa con hueco rectangular opcional hole = {x0,z0,x1,z1}. */
    public void slab(float y0, float y1, int mt, int mb, float x0, float z0, float x1, float z1, float[] hole) {
        if (hole == null) {
            box(mt, mb, CONC, x0, y0, z0, x1, y1, z1, true);
            return;
        }
        box(mt, mb, CONC, x0, y0, z0, x1, y1, hole[1], true);
        box(mt, mb, CONC, x0, y0, hole[3], x1, y1, z1, true);
        box(mt, mb, CONC, x0, y0, hole[1], hole[0], y1, hole[3], true);
        box(mt, mb, CONC, hole[2], y0, hole[1], x1, y1, hole[3], true);
    }

    /** Escalera que avanza en X: el primer escalon empieza en xFrom y baja hacia dir (+1/-1). */
    public void stairsX(float xFrom, float dir, float z0, float z1, float yTop, float yBot, int n) {
        float rise = (yTop - yBot) / (n + 1), run = 0.4f;
        for (int i = 0; i < n; i++) {
            float top = yTop - (i + 1) * rise;
            float xa = xFrom + dir * i * run, xb = xFrom + dir * (i + 1) * run;
            box(CONC, CONC, CONC, xa, yBot - 0.1f, z0, xb, top, z1, true);
        }
    }

    public void stairsZ(float zFrom, float dir, float x0, float x1, float yTop, float yBot, int n) {
        float rise = (yTop - yBot) / (n + 1), run = 0.4f;
        for (int i = 0; i < n; i++) {
            float top = yTop - (i + 1) * rise;
            float za = zFrom + dir * i * run, zb = zFrom + dir * (i + 1) * run;
            box(CONC, CONC, CONC, x0, yBot - 0.1f, za, x1, top, zb, true);
        }
    }

    public Light light(float x, float y, float z, float r, float g, float b, float rad, int mode) {
        Light l = new Light();
        l.x = x; l.y = y; l.z = z; l.r = r; l.g = g; l.b = b; l.rad = rad; l.mode = mode;
        l.phase = (float) Math.random() * 10f;
        lights.add(l);
        return l;
    }

    public void pickup(int type, float x, float y, float z) {
        Pickup p = new Pickup();
        p.type = type; p.x = x; p.y = y; p.z = z;
        pickups.add(p);
    }

    public void spawn(int type, float x, float y, float z) {
        Spawn s = new Spawn();
        s.type = type; s.x = x; s.y = y; s.z = z;
        idleSpawns.add(s);
    }

    // ------------------------------------------------------------------ fisica

    public boolean blocked(float x, float y, float z, float r, float h) {
        for (int i = 0, n = solids.size(); i < n; i++) {
            Box b = solids.get(i);
            if (x + r > b.x0 && x - r < b.x1 && z + r > b.z0 && z - r < b.z1 && b.y1 > y + STEP && b.y0 < y + h) return true;
        }
        return false;
    }

    public float groundAt(float x, float y, float z, float r) {
        float best = -100f;
        float rr = r * 0.8f;
        for (int i = 0, n = solids.size(); i < n; i++) {
            Box b = solids.get(i);
            if (x + rr > b.x0 && x - rr < b.x1 && z + rr > b.z0 && z - rr < b.z1 && b.y1 <= y + STEP + 0.001f && b.y1 > best) best = b.y1;
        }
        return best;
    }

    public float rayDist(float ox, float oy, float oz, float dx, float dy, float dz, float max) {
        float best = max;
        for (int i = 0, n = solids.size(); i < n; i++) {
            Box b = solids.get(i);
            float t = Util.rayBox(ox, oy, oz, dx, dy, dz, b.x0, b.y0, b.z0, b.x1, b.y1, b.z1);
            if (t >= 0f && t < best) best = t;
        }
        return best;
    }

    // ------------------------------------------------------------------ render

    public void render() {
        for (int i = 0; i < NMAT; i++) {
            Mat m = mats[i];
            if (m.set.meshes.isEmpty()) continue;
            Gfx.setTex(m.tex);
            Gfx.setColor(m.r, m.g, m.b);
            Gfx.setEmis(m.er, m.eg, m.eb);
            for (Mesh me : m.set.meshes) Gfx.drawStatic(me);
        }
        Gfx.setEmis(0, 0, 0);
    }
}
