package com.jhon.test;

/** Jhon, el sobreviviente (camara en primera persona). */
public class Player extends Ent {
    public float yaw, pitch;          // grados; adelante = (-sin yaw, 0, -cos yaw)
    public float hp = 100f;
    public boolean dead;
    public float hurtT;               // destello rojo al recibir dano
    public float camY;                // altura suavizada de la camara
    public boolean flashlight = true;

    public final boolean[] has = new boolean[Weapons.COUNT];
    public final int[] mag = new int[Weapons.COUNT];
    public final int[] res = new int[Weapons.COUNT];
    public int cur = Weapons.PISTOL;

    public float fireCd, reloadT, swingT = -1f, raise = 1f, flashT, recoil, heat, pump;
    public boolean reloading, swingHit;
    public float bobT, stepDist, bobAmt;
    public float hitMarker;

    public Player() {
        r = 0.3f;
        h = 1.75f;
    }

    public void reset(Level L) {
        x = L.startX; y = L.startY; z = L.startZ; vy = 0f; grounded = false;
        yaw = L.startYaw; pitch = 0f;
        hp = 100f; dead = false; hurtT = 0f;
        camY = y + 1.62f;
        flashlight = true;
        for (int i = 0; i < Weapons.COUNT; i++) { has[i] = false; mag[i] = 0; res[i] = 0; }
        has[Weapons.PISTOL] = true;
        mag[Weapons.PISTOL] = Weapons.MAG[Weapons.PISTOL];
        res[Weapons.PISTOL] = 45;
        cur = Weapons.PISTOL;
        fireCd = 0f; reloadT = 0f; swingT = -1f; raise = 1f; flashT = 0f; recoil = 0f; heat = 0f; pump = 0f;
        reloading = false; swingHit = false; hitMarker = 0f;
    }

    public float dirX() { return (float) -Math.sin(Math.toRadians(yaw)); }
    public float dirZ() { return (float) -Math.cos(Math.toRadians(yaw)); }
}
