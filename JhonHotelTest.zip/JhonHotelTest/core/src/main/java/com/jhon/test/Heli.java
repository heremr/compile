package com.jhon.test;

import com.badlogic.gdx.math.Matrix4;

/** Helicoptero de rescate (modelo de cajas). Orientacion: la nariz apunta a +Z local; yaw como en los zombis. */
public class Heli {
    public float x, y, z, yaw, pitch, roll;
    public float rotor;       // angulo actual de las palas
    public float rotorSpeed;  // grados/seg
    public boolean visible = true;

    static final Matrix4 b = new Matrix4(), m = new Matrix4();

    public void update(float dt) {
        rotor += rotorSpeed * dt;
        if (rotor > 36000f) rotor -= 36000f;
    }

    static void pt(Matrix4 mm, float ox, float oy, float oz, float sx, float sy, float sz, float r, float g, float bl) {
        Gfx.setColor(r, g, bl);
        Gfx.box(mm, ox, oy, oz, sx, sy, sz);
    }

    public void draw(Level L) {
        if (!visible) return;
        b.idt().translate(x, y, z).rotate(0, 1, 0, yaw).rotate(1, 0, 0, pitch).rotate(0, 0, 1, roll);
        Gfx.setTex(L.tMetal);
        Gfx.setEmis(0f, 0f, 0f);
        float or = 0.20f, og = 0.24f, ob = 0.17f;
        pt(b, 0f, 1.2f, 0f, 1.7f, 1.4f, 3.0f, or, og, ob);                // cabina
        pt(b, 0f, 0.95f, 1.9f, 1.4f, 0.95f, 1.1f, or, og, ob);            // nariz
        pt(b, 0f, 2.1f, -0.3f, 1.0f, 0.5f, 1.6f, or * 0.8f, og * 0.8f, ob * 0.8f); // motor
        pt(b, 0f, 1.35f, -3.8f, 0.35f, 0.45f, 4.6f, or, og, ob);          // cola
        pt(b, 0f, 2.05f, -5.9f, 0.12f, 1.1f, 0.8f, or, og, ob);           // aleta
        pt(b, 0f, 1.5f, -5.5f, 1.4f, 0.07f, 0.5f, or, og, ob);            // estabilizador
        pt(b, 0f, 0.55f, 0.2f, 1.6f, 0.12f, 3.2f, 0.1f, 0.11f, 0.1f);     // panza
        // vidrios
        Gfx.setTex(null);
        Gfx.setEmis(0.03f, 0.06f, 0.1f);
        pt(b, 0f, 1.35f, 2.1f, 1.3f, 0.55f, 0.75f, 0.06f, 0.1f, 0.15f);
        pt(b, 0.87f, 1.4f, 0.4f, 0.02f, 0.5f, 1.4f, 0.06f, 0.1f, 0.15f);
        pt(b, -0.87f, 1.4f, 0.4f, 0.02f, 0.5f, 1.4f, 0.06f, 0.1f, 0.15f);
        // luces de posicion
        Gfx.setEmis(1f, 0.1f, 0.05f);
        pt(b, 0.9f, 1.0f, -0.2f, 0.1f, 0.1f, 0.1f, 0f, 0f, 0f);
        Gfx.setEmis(0.1f, 1f, 0.2f);
        pt(b, -0.9f, 1.0f, -0.2f, 0.1f, 0.1f, 0.1f, 0f, 0f, 0f);
        Gfx.setEmis(1f, 1f, 0.9f);
        pt(b, 0f, 0.75f, 2.45f, 0.4f, 0.2f, 0.12f, 0f, 0f, 0f);
        Gfx.setEmis(0f, 0f, 0f);
        // patines
        Gfx.setTex(L.tMetal);
        for (int s = -1; s <= 1; s += 2) {
            pt(b, s * 0.95f, 0.08f, 0.1f, 0.08f, 0.08f, 3.8f, 0.08f, 0.08f, 0.08f);
            pt(b, s * 0.93f, 0.4f, 0.9f, 0.06f, 0.7f, 0.06f, 0.08f, 0.08f, 0.08f);
            pt(b, s * 0.93f, 0.4f, -0.7f, 0.06f, 0.7f, 0.06f, 0.08f, 0.08f, 0.08f);
        }
        // rotor principal
        pt(b, 0f, 2.5f, 0f, 0.16f, 0.4f, 0.16f, 0.05f, 0.05f, 0.05f);
        for (int i = 0; i < 4; i++) {
            m.set(b).translate(0f, 2.75f, 0f).rotate(0, 1, 0, rotor + i * 90f);
            pt(m, 0f, 0f, 2.4f, 0.28f, 0.03f, 4.6f, 0.06f, 0.06f, 0.06f);
        }
        // rotor de cola
        for (int i = 0; i < 2; i++) {
            m.set(b).translate(0.2f, 2.0f, -6.0f).rotate(1, 0, 0, rotor * 1.6f + i * 90f);
            pt(m, 0f, 0f, 0f, 0.03f, 1.3f, 0.12f, 0.06f, 0.06f, 0.06f);
        }
    }
}
