package com.jhon.test;

import com.badlogic.gdx.graphics.Color;
import com.badlogic.gdx.graphics.Pixmap;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.glutils.PixmapTextureData;

/** Texturas procedurales (sin archivos de imagen). Todas son 256x256 y se repiten sin costuras. */
public class Tex {
    interface Px { void at(float u, float v, float[] c); }

    static float hash(int x, int y, int s) {
        int h = x * 374761393 + y * 668265263 + s * 1274126177;
        h = (h ^ (h >>> 13)) * 1274126177;
        h ^= (h >>> 16);
        return (h & 0xffff) / 65535f;
    }

    static float vn(float u, float v, int cells, int seed) {
        float x = u * cells, y = v * cells;
        int xi = (int) Math.floor(x), yi = (int) Math.floor(y);
        float xf = x - xi, yf = y - yi;
        xf = xf * xf * (3 - 2 * xf);
        yf = yf * yf * (3 - 2 * yf);
        int x0 = ((xi % cells) + cells) % cells, x1 = (x0 + 1) % cells;
        int y0 = ((yi % cells) + cells) % cells, y1 = (y0 + 1) % cells;
        float a = hash(x0, y0, seed), b = hash(x1, y0, seed), c = hash(x0, y1, seed), d = hash(x1, y1, seed);
        float top = a + (b - a) * xf, bot = c + (d - c) * xf;
        return top + (bot - top) * yf;
    }

    static float fbm(float u, float v, int cells, int oct, int seed) {
        float a = 0, amp = 0.5f, sum = 0;
        int c = cells;
        for (int i = 0; i < oct; i++) {
            a += amp * vn(u, v, c, seed + i * 7);
            sum += amp;
            amp *= 0.5f;
            c *= 2;
        }
        return a / sum;
    }

    static float frac(float x) { return x - (float) Math.floor(x); }
    static float cl(float x) { return x < 0 ? 0 : (x > 1 ? 1 : x); }

    static Texture gen(Px px) {
        int n = 256;
        Pixmap p = new Pixmap(n, n, Pixmap.Format.RGBA8888);
        float[] c = new float[3];
        for (int y = 0; y < n; y++) {
            for (int x = 0; x < n; x++) {
                px.at(x / (float) n, y / (float) n, c);
                float j = (hash(x, y, 99) - 0.5f) * 0.05f; // grano fino
                p.drawPixel(x, y, Color.rgba8888(cl(c[0] + j), cl(c[1] + j), cl(c[2] + j), 1f));
            }
        }
        // textura "managed": se restaura sola si Android pierde el contexto GL (por eso no se libera el Pixmap)
        Texture t = new Texture(new PixmapTextureData(p, Pixmap.Format.RGBA8888, true, false, true));
        t.setFilter(Texture.TextureFilter.MipMapLinearLinear, Texture.TextureFilter.Linear);
        t.setWrap(Texture.TextureWrap.Repeat, Texture.TextureWrap.Repeat);
        return t;
    }

    static void set(float[] c, float r, float g, float b, float k) {
        c[0] = r * k; c[1] = g * k; c[2] = b * k;
    }

    public static Texture wallpaper() {
        return gen(new Px() {
            public void at(float u, float v, float[] c) {
                float st = 0.5f + 0.5f * (float) Math.sin(u * 6.2832f * 8f);
                float k = 0.88f + 0.12f * st;
                float d = Math.abs(frac(u * 8f) - 0.5f) + Math.abs(frac(v * 8f) - 0.5f);
                if (d < 0.17f) k *= 0.93f;
                float g = fbm(u, v, 4, 4, 11);
                k *= 0.62f + 0.55f * g;
                set(c, 0.80f, 0.71f, 0.55f, k);
            }
        });
    }

    public static Texture carpet() {
        return gen(new Px() {
            public void at(float u, float v, float[] c) {
                float d = Math.abs(frac(u * 4f) - 0.5f) + Math.abs(frac(v * 4f) - 0.5f);
                float k = 0.7f + 0.5f * fbm(u, v, 8, 3, 21);
                set(c, 0.42f, 0.08f, 0.10f, k);
                if (Math.abs(d - 0.36f) < 0.022f) { c[0] = 0.55f * k; c[1] = 0.38f * k; c[2] = 0.14f * k; }
                if (d < 0.07f) { c[0] *= 1.35f; c[1] *= 1.2f; }
            }
        });
    }

    public static Texture tile() {
        return gen(new Px() {
            public void at(float u, float v, float[] c) {
                int ck = ((int) (u * 4f) + (int) (v * 4f)) & 1;
                float m = fbm(u, v, 3, 5, 31);
                float k = 0.65f + 0.5f * m;
                if (ck == 0) set(c, 0.84f, 0.81f, 0.74f, k); else set(c, 0.20f, 0.17f, 0.16f, k * 1.2f);
                float fu = frac(u * 4f), fv = frac(v * 4f);
                if (fu < 0.012f || fu > 0.988f || fv < 0.012f || fv > 0.988f) set(c, 0.08f, 0.08f, 0.08f, 1f);
            }
        });
    }

    public static Texture ceiling() {
        return gen(new Px() {
            public void at(float u, float v, float[] c) {
                float k = 0.65f + 0.45f * fbm(u, v, 4, 4, 41);
                set(c, 0.82f, 0.82f, 0.79f, k);
                float fu = frac(u * 4f), fv = frac(v * 4f);
                if (fu < 0.015f || fu > 0.985f || fv < 0.015f || fv > 0.985f) set(c, 0.35f, 0.35f, 0.34f, 1f);
            }
        });
    }

    public static Texture concrete() {
        return gen(new Px() {
            public void at(float u, float v, float[] c) {
                float f = fbm(u, v, 4, 5, 51);
                set(c, 0.52f, 0.52f, 0.50f, 0.45f + 0.7f * f);
            }
        });
    }

    public static Texture asphalt() {
        return gen(new Px() {
            public void at(float u, float v, float[] c) {
                float f = fbm(u, v, 8, 4, 61);
                float k = 0.55f + 0.7f * f;
                if (hash((int) (u * 256), (int) (v * 256), 5) > 0.975f) k = 2.2f;
                set(c, 0.17f, 0.17f, 0.18f, k);
            }
        });
    }

    public static Texture metal() {
        return gen(new Px() {
            public void at(float u, float v, float[] c) {
                float s = hash(0, (int) (v * 256), 7) * 0.18f;
                float f = fbm(u, v, 4, 3, 71);
                set(c, 0.46f, 0.48f, 0.52f, 0.65f + 0.5f * f + s);
            }
        });
    }

    public static Texture wood() {
        return gen(new Px() {
            public void at(float u, float v, float[] c) {
                float w = fbm(u, v, 2, 3, 81);
                float g = 0.5f + 0.5f * (float) Math.sin((v * 12f + w * 5f) * 6.2832f);
                set(c, 0.38f, 0.22f, 0.11f, 0.65f + 0.4f * g);
            }
        });
    }

    /** Ruido gris suave para multiplicar por un color (ropa, piel, armas). */
    public static Texture grain() {
        return gen(new Px() {
            public void at(float u, float v, float[] c) {
                float k = 0.72f + 0.34f * fbm(u, v, 8, 3, 91);
                set(c, 1f, 1f, 1f, k);
            }
        });
    }
}
