package com.jhon.test;

public class Util {
    /** Distancia a la que un rayo (dir normalizada) entra en una caja alineada a los ejes; -1 si no la toca. */
    public static float rayBox(float ox, float oy, float oz, float dx, float dy, float dz,
                               float x0, float y0, float z0, float x1, float y1, float z1) {
        float tmin = 0f, tmax = Float.MAX_VALUE;
        if (Math.abs(dx) < 1e-8f) {
            if (ox < x0 || ox > x1) return -1f;
        } else {
            float t1 = (x0 - ox) / dx, t2 = (x1 - ox) / dx;
            if (t1 > t2) { float s = t1; t1 = t2; t2 = s; }
            if (t1 > tmin) tmin = t1;
            if (t2 < tmax) tmax = t2;
            if (tmin > tmax) return -1f;
        }
        if (Math.abs(dy) < 1e-8f) {
            if (oy < y0 || oy > y1) return -1f;
        } else {
            float t1 = (y0 - oy) / dy, t2 = (y1 - oy) / dy;
            if (t1 > t2) { float s = t1; t1 = t2; t2 = s; }
            if (t1 > tmin) tmin = t1;
            if (t2 < tmax) tmax = t2;
            if (tmin > tmax) return -1f;
        }
        if (Math.abs(dz) < 1e-8f) {
            if (oz < z0 || oz > z1) return -1f;
        } else {
            float t1 = (z0 - oz) / dz, t2 = (z1 - oz) / dz;
            if (t1 > t2) { float s = t1; t1 = t2; t2 = s; }
            if (t1 > tmin) tmin = t1;
            if (t2 < tmax) tmax = t2;
            if (tmin > tmax) return -1f;
        }
        return tmin;
    }

    public static float clamp(float v, float a, float b) { return v < a ? a : (v > b ? b : v); }
    public static float lerp(float a, float b, float t) { return a + (b - a) * t; }
    public static float rnd(float a, float b) { return a + (float) Math.random() * (b - a); }

    public static float angleDiff(float a, float b) {
        float d = (b - a) % 360f;
        if (d > 180f) d -= 360f;
        if (d < -180f) d += 360f;
        return d;
    }

    /** Piso (0 lobby, 1 pasillo/cuartos, 2 azotea) segun la altura de los pies (el cambio ocurre al final de cada escalera). */
    public static int floorOf(float y) {
        return y < 3.5f ? 0 : (y < 7.5f ? 1 : 2);
    }
}
