package com.jhon.test;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.graphics.GL20;
import com.badlogic.gdx.graphics.Mesh;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.VertexAttribute;
import com.badlogic.gdx.graphics.VertexAttributes;
import com.badlogic.gdx.graphics.g3d.utils.MeshBuilder;
import com.badlogic.gdx.graphics.glutils.ShaderProgram;
import com.badlogic.gdx.math.Matrix3;
import com.badlogic.gdx.math.Matrix4;

import java.util.ArrayList;

/** Renderer minimo: un shader con iluminacion por pixel (luces puntuales + linterna + niebla). */
public class Gfx {
    public static final int NL = 6; // luces puntuales simultaneas (bajar a 4 en moviles lentos)

    public static final float[] lp = new float[NL * 3];
    public static final float[] lc = new float[NL * 3];
    public static final float[] lr = new float[NL];

    static ShaderProgram sh;
    static Mesh cube;
    static Texture white;
    static final Matrix4 ID = new Matrix4();
    static final Matrix4 tmp = new Matrix4();
    static final Matrix3 nm = new Matrix3();

    static final VertexAttributes ATTR = new VertexAttributes(
            VertexAttribute.Position(), VertexAttribute.Normal(), VertexAttribute.TexCoords(0));

    static final String VS =
            "attribute vec3 a_position;\n" +
            "attribute vec3 a_normal;\n" +
            "attribute vec2 a_texCoord0;\n" +
            "uniform mat4 u_proj;\n" +
            "uniform mat4 u_model;\n" +
            "uniform mat3 u_nrm;\n" +
            "uniform vec2 u_uv;\n" +
            "varying vec3 v_pos;\n" +
            "varying vec3 v_nrm;\n" +
            "varying vec2 v_uv;\n" +
            "void main(){\n" +
            "  vec4 w = u_model * vec4(a_position, 1.0);\n" +
            "  v_pos = w.xyz;\n" +
            "  v_nrm = normalize(u_nrm * a_normal);\n" +
            "  v_uv = a_texCoord0 * u_uv;\n" +
            "  gl_Position = u_proj * w;\n" +
            "}\n";

    static final String FS =
            "#ifdef GL_ES\n#ifdef GL_FRAGMENT_PRECISION_HIGH\nprecision highp float;\n#else\nprecision mediump float;\n#endif\n#endif\n" +
            "const int NL = " + NL + ";\n" +
            "varying vec3 v_pos;\nvarying vec3 v_nrm;\nvarying vec2 v_uv;\n" +
            "uniform sampler2D u_tex;\n" +
            "uniform vec4 u_color;\nuniform float u_useTex;\nuniform vec3 u_emis;\n" +
            "uniform vec3 u_amb;\nuniform vec3 u_cam;\nuniform vec3 u_fogCol;\nuniform float u_fog;\nuniform float u_vm;\n" +
            "uniform vec3 u_lp[NL];\nuniform vec3 u_lc[NL];\nuniform float u_lr[NL];\n" +
            "uniform vec3 u_sp;\nuniform vec3 u_sd;\nuniform float u_sOn;\n" +
            "void main(){\n" +
            "  vec4 base = u_color;\n" +
            "  if (u_useTex > 0.5) base *= texture2D(u_tex, v_uv);\n" +
            "  vec3 n = normalize(v_nrm);\n" +
            "  vec3 light = u_amb;\n" +
            "  for (int i = 0; i < NL; i++) {\n" +
            "    vec3 d = u_lp[i] - v_pos;\n" +
            "    float dist = length(d) + 0.001;\n" +
            "    float att = clamp(1.0 - dist / u_lr[i], 0.0, 1.0);\n" +
            "    att *= att;\n" +
            "    float nd = max(dot(n, d / dist), 0.0);\n" +
            "    light += u_lc[i] * att * (nd * 0.9 + 0.1);\n" +
            "  }\n" +
            "  vec3 sd = u_sp - v_pos;\n" +
            "  float sdist = length(sd) + 0.001;\n" +
            "  vec3 sdn = sd / sdist;\n" +
            "  float cone = dot(-sdn, u_sd);\n" +
            "  float spot = smoothstep(0.82, 0.94, cone) * u_sOn;\n" +
            "  float satt = clamp(1.0 - sdist / 30.0, 0.0, 1.0);\n" +
            "  light += vec3(1.0, 0.95, 0.82) * spot * satt * satt * (max(dot(n, sdn), 0.0) * 0.9 + 0.1) * 1.7;\n" +
            "  vec3 col = base.rgb * light + u_emis;\n" +
            "  float fd = length(v_pos - u_cam);\n" +
            "  float f = clamp(1.0 - exp(-fd * u_fog), 0.0, 1.0) * (1.0 - u_vm);\n" +
            "  col = mix(col, u_fogCol, f);\n" +
            "  gl_FragColor = vec4(col, base.a);\n" +
            "}\n";

    public static void init() {
        ShaderProgram.pedantic = false;
        sh = new ShaderProgram(VS, FS);
        if (!sh.isCompiled()) throw new RuntimeException("Shader error: " + sh.getLog());
        MeshBuilder mb = new MeshBuilder();
        mb.begin(ATTR, GL20.GL_TRIANGLES);
        boxFaces(mb, mb, mb, -0.5f, -0.5f, -0.5f, 0.5f, 0.5f, 0.5f, 1f, 1f, 1f);
        cube = mb.end();
        com.badlogic.gdx.graphics.Pixmap p = new com.badlogic.gdx.graphics.Pixmap(2, 2, com.badlogic.gdx.graphics.Pixmap.Format.RGBA8888);
        p.setColor(1, 1, 1, 1);
        p.fill();
        white = new Texture(new com.badlogic.gdx.graphics.glutils.PixmapTextureData(p, com.badlogic.gdx.graphics.Pixmap.Format.RGBA8888, false, false, true));
    }

    // ---------------------------------------------------------------- mallas estaticas

    public static class MeshSet {
        final MeshBuilder mb = new MeshBuilder();
        final ArrayList<Mesh> meshes = new ArrayList<Mesh>();
        boolean open = false;

        public MeshBuilder b() {
            if (!open) {
                mb.begin(ATTR, GL20.GL_TRIANGLES);
                open = true;
            } else if (mb.getNumVertices() > 60000) {
                meshes.add(mb.end());
                mb.begin(ATTR, GL20.GL_TRIANGLES);
            }
            return mb;
        }

        public void finish() {
            if (open) {
                meshes.add(mb.end());
                open = false;
            }
        }
    }

    static void rect(MeshBuilder b, float u2, float v2,
                     float ax, float ay, float az, float bx, float by, float bz,
                     float cx, float cy, float cz, float dx, float dy, float dz,
                     float nx, float ny, float nz) {
        b.setUVRange(0f, 0f, u2, v2);
        b.rect(ax, ay, az, bx, by, bz, cx, cy, cz, dx, dy, dz, nx, ny, nz);
    }

    /** Agrega las 6 caras de una caja; arriba/abajo/lados pueden ir a mallas (materiales) distintas. */
    public static void boxFaces(MeshBuilder top, MeshBuilder bot, MeshBuilder side,
                                float x0, float y0, float z0, float x1, float y1, float z1,
                                float tTop, float tBot, float tSide) {
        float dx = x1 - x0, dy = y1 - y0, dz = z1 - z0;
        if (top != null) rect(top, dx / tTop, dz / tTop, x0, y1, z0, x1, y1, z0, x1, y1, z1, x0, y1, z1, 0, 1, 0);
        if (bot != null) rect(bot, dx / tBot, dz / tBot, x0, y0, z1, x1, y0, z1, x1, y0, z0, x0, y0, z0, 0, -1, 0);
        if (side != null) {
            rect(side, dx / tSide, dy / tSide, x0, y0, z1, x1, y0, z1, x1, y1, z1, x0, y1, z1, 0, 0, 1);
            rect(side, dx / tSide, dy / tSide, x1, y0, z0, x0, y0, z0, x0, y1, z0, x1, y1, z0, 0, 0, -1);
            rect(side, dz / tSide, dy / tSide, x1, y0, z0, x1, y0, z1, x1, y1, z1, x1, y1, z0, 1, 0, 0);
            rect(side, dz / tSide, dy / tSide, x0, y0, z1, x0, y0, z0, x0, y1, z0, x0, y1, z1, -1, 0, 0);
        }
    }

    // ---------------------------------------------------------------- estado por frame

    public static void begin(Matrix4 proj, float cx, float cy, float cz,
                             float ambR, float ambG, float ambB,
                             float fogR, float fogG, float fogB, float fogDensity) {
        Gdx.gl.glEnable(GL20.GL_DEPTH_TEST);
        Gdx.gl.glDepthFunc(GL20.GL_LEQUAL);
        Gdx.gl.glDisable(GL20.GL_CULL_FACE);
        sh.bind();
        sh.setUniformMatrix("u_proj", proj);
        sh.setUniformf("u_cam", cx, cy, cz);
        sh.setUniformf("u_amb", ambR, ambG, ambB);
        sh.setUniformf("u_fogCol", fogR, fogG, fogB);
        sh.setUniformf("u_fog", fogDensity);
        sh.setUniformf("u_vm", 0f);
        sh.setUniformi("u_tex", 0);
        sh.setUniform3fv("u_lp[0]", lp, 0, NL * 3);
        sh.setUniform3fv("u_lc[0]", lc, 0, NL * 3);
        sh.setUniform1fv("u_lr[0]", lr, 0, NL);
        setEmis(0, 0, 0);
        setUV(1, 1);
    }

    public static void setSpot(float px, float py, float pz, float dx, float dy, float dz, boolean on) {
        sh.setUniformf("u_sp", px, py, pz);
        sh.setUniformf("u_sd", dx, dy, dz);
        sh.setUniformf("u_sOn", on ? 1f : 0f);
    }

    public static void setProj(Matrix4 proj, boolean viewmodel) {
        sh.setUniformMatrix("u_proj", proj);
        sh.setUniformf("u_vm", viewmodel ? 1f : 0f);
    }

    public static void setTex(Texture t) {
        if (t == null) {
            white.bind(0);
            sh.setUniformf("u_useTex", 0f);
        } else {
            t.bind(0);
            sh.setUniformf("u_useTex", 1f);
        }
    }

    public static void setColor(float r, float g, float b) {
        sh.setUniformf("u_color", r, g, b, 1f);
    }

    public static void setEmis(float r, float g, float b) {
        sh.setUniformf("u_emis", r, g, b);
    }

    public static void setUV(float su, float sv) {
        sh.setUniformf("u_uv", su, sv);
    }

    // ---------------------------------------------------------------- dibujo

    public static void drawStatic(Mesh m) {
        sh.setUniformMatrix("u_model", ID);
        sh.setUniformMatrix("u_nrm", nm.idt());
        setUV(1, 1);
        m.render(sh, GL20.GL_TRIANGLES);
    }

    /** Caja unitaria transformada: base * traslacion(ox,oy,oz) * escala(sx,sy,sz). */
    public static void box(Matrix4 base, float ox, float oy, float oz, float sx, float sy, float sz) {
        tmp.set(base).translate(ox, oy, oz).scale(sx, sy, sz);
        sh.setUniformMatrix("u_model", tmp);
        nm.set(tmp);
        nm.inv().transpose();
        sh.setUniformMatrix("u_nrm", nm);
        cube.render(sh, GL20.GL_TRIANGLES);
    }

    /** Igual que box pero con rotacion local (grados) alrededor de X, Y, Z aplicada antes de escalar. */
    public static void boxR(Matrix4 base, float ox, float oy, float oz, float rx, float ry, float rz,
                            float sx, float sy, float sz) {
        tmp.set(base).translate(ox, oy, oz);
        if (ry != 0) tmp.rotate(0, 1, 0, ry);
        if (rx != 0) tmp.rotate(1, 0, 0, rx);
        if (rz != 0) tmp.rotate(0, 0, 1, rz);
        tmp.scale(sx, sy, sz);
        sh.setUniformMatrix("u_model", tmp);
        nm.set(tmp);
        nm.inv().transpose();
        sh.setUniformMatrix("u_nrm", nm);
        cube.render(sh, GL20.GL_TRIANGLES);
    }

    /** Caja en coordenadas de mundo (centro + tamano) sin rotacion. */
    public static void worldBox(float cx, float cy, float cz, float sx, float sy, float sz) {
        box(ID, cx, cy, cz, sx, sy, sz);
    }
}
