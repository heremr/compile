package com.jhon.test;

import java.util.Random;

import static com.jhon.test.Level.*;

/**
 * "Hotel Mirador": nivel de diseno propio. Azotea con helipad -> casa de escaleras -> piso 1 (pasillo y cuartos)
 * -> lobby con recepcion y alarma -> calle donde aterriza el helicoptero de rescate.
 * Sistema de coordenadas: X este, Z sur, Y arriba. Edificio de 40 x 24 m.
 */
public class Hotel {
    static final float F0 = 0.05f, F1 = 4f, F2 = 8f, C0 = 3.6f, C1 = 7.6f;

    static void build(Level L) {
        Random rnd = new Random(42);
        street(L, rnd);
        shell(L);
        lobby(L, rnd);
        floor1(L);
        roof(L);
        itemsAndSpawns(L);
        L.startX = 24f; L.startY = F2; L.startZ = 12f; L.startYaw = 90f;
        L.padX = 10f; L.padY = F2 + 0.02f; L.padZ = 12f;
        L.lzX = 20f; L.lzZ = 42f;
        L.alarmX = 29.5f; L.alarmY = 1.2f; L.alarmZ = 4.7f;
    }

    // caja en coordenadas locales (u a lo largo, v a lo ancho) alrededor de (cx,cz)
    static void bl(Level L, int m, float cx, float cz, boolean alongX, float u0, float v0, float u1, float v1, float y0, float y1) {
        if (alongX) L.b(m, cx + u0, y0, cz + v0, cx + u1, y1, cz + v1);
        else L.b(m, cx + v0, y0, cz + u0, cx + v1, y1, cz + u1);
    }

    // ------------------------------------------------------------------ exterior

    static void car(Level L, float cx, float cz, boolean alongX, int mat) {
        bl(L, BLACK, cx, cz, alongX, -1.6f, -0.85f, 1.6f, 0.85f, 0f, 0.4f);
        bl(L, mat, cx, cz, alongX, -2.2f, -0.9f, 2.2f, 0.9f, 0.4f, 1.0f);
        bl(L, mat, cx, cz, alongX, -1.1f, -0.8f, 1.0f, 0.8f, 1.0f, 1.5f);
        bl(L, GLASS, cx, cz, alongX, -1.0f, -0.82f, 0.9f, 0.82f, 1.05f, 1.45f);
    }

    static void pole(Level L, float x, float z, float h, boolean light) {
        L.b(BLACK, x - 0.1f, 0f, z - 0.1f, x + 0.1f, h, z + 0.1f);
        L.nb(LAMP, x - 0.4f, h, z - 0.2f, x + 0.4f, h + 0.12f, z + 0.2f);
        if (light) L.light(x, h - 0.5f, z, 1.0f, 0.82f, 0.55f, 15f, 0);
    }

    static void farBuilding(Level L, Random rnd, float cx, float cz, float w, float d, float h, int faceX, int faceZ) {
        L.nb(DARKCONC, cx - w / 2, 0f, cz - d / 2, cx + w / 2, h, cz + d / 2);
        for (float y = 4f; y < h - 2f; y += 3f) {
            for (float o = -w / 2 + 1.5f; o < w / 2 - 1f; o += 3f) {
                if (rnd.nextFloat() > 0.16f) continue;
                if (faceZ != 0) {
                    float z = cz + faceZ * (d / 2 + 0.04f);
                    L.nb(LITWIN, cx + o, y, z - 0.03f, cx + o + 1.3f, y + 1.4f, z + 0.03f);
                } else {
                    float x = cx + faceX * (w / 2 + 0.04f);
                    L.nb(LITWIN, x - 0.03f, y, cz + o, x + 0.03f, y + 1.4f, cz + o + 1.3f);
                }
            }
        }
    }

    static void street(Level L, Random rnd) {
        L.b(ASPH, -40f, -1f, -40f, 80f, 0f, 64f);
        L.b(CONC, -3f, 0f, 24.2f, 43f, 0.15f, 29f);
        for (float x = -24f; x < 62f; x += 6f) L.nb(YELLOW, x, 0f, 49.9f, x + 3f, 0.02f, 50.1f);
        // marcas de la zona de aterrizaje (calle frente al hotel)
        L.nb(YELLOW, 13f, 0f, 35f, 27f, 0.03f, 35.3f);
        L.nb(YELLOW, 13f, 0f, 48.7f, 27f, 0.03f, 49f);
        L.nb(YELLOW, 13f, 0f, 35f, 13.3f, 0.03f, 49f);
        L.nb(YELLOW, 26.7f, 0f, 35f, 27f, 0.03f, 49f);
        L.nb(YELLOW, 18.2f, 0f, 40f, 18.5f, 0.03f, 44f);
        L.nb(YELLOW, 21.5f, 0f, 40f, 21.8f, 0.03f, 44f);
        L.nb(YELLOW, 18.5f, 0f, 41.85f, 21.5f, 0.03f, 42.15f);

        // limites del mapa
        L.b(CONC, -26f, 0f, -23f, 66f, 6f, -22f);
        L.b(CONC, -26f, 0f, 60f, 66f, 6f, 61f);
        L.b(CONC, -26f, 0f, -23f, -25f, 6f, 61f);
        L.b(CONC, 65f, 0f, -23f, 66f, 6f, 61f);
        for (float x = -50f; x < 90f; x += 13f) {
            farBuilding(L, rnd, x, -34f - rnd.nextFloat() * 8f, 9f + rnd.nextFloat() * 5f, 10f, 18f + rnd.nextFloat() * 30f, 0, 1);
            farBuilding(L, rnd, x, 72f + rnd.nextFloat() * 8f, 9f + rnd.nextFloat() * 5f, 10f, 18f + rnd.nextFloat() * 30f, 0, -1);
        }
        for (float z = -30f; z < 66f; z += 13f) {
            farBuilding(L, rnd, -38f - rnd.nextFloat() * 8f, z, 10f, 9f + rnd.nextFloat() * 5f, 18f + rnd.nextFloat() * 30f, 1, 0);
            farBuilding(L, rnd, 78f + rnd.nextFloat() * 8f, z, 10f, 9f + rnd.nextFloat() * 5f, 18f + rnd.nextFloat() * 30f, -1, 0);
        }

        // autos abandonados y obstaculos
        car(L, 8f, 36f, true, CARRED);
        car(L, 30f, 34f, false, CARBLUE);
        car(L, -6f, 30f, true, CARGREY);
        car(L, 46f, 38f, true, CARRED);
        car(L, 52f, 30f, false, CARGREY);
        car(L, -12f, 44f, true, CARBLUE);
        car(L, 40f, 54f, true, CARGREY);
        L.b(CONC, 0f, 0f, 31f, 3.2f, 0.85f, 31.6f);
        L.b(CONC, 34f, 0f, 44f, 34.6f, 0.85f, 47.2f);
        L.b(METAL, 44f, 0f, 25.5f, 46.4f, 1.3f, 27f);
        for (int i = 0; i < 14; i++) {
            float x = -20f + rnd.nextFloat() * 80f, z = 28f + rnd.nextFloat() * 28f;
            if (x > 12f && x < 28f && z > 33f && z < 51f) continue;
            float s = 0.3f + rnd.nextFloat() * 0.6f;
            L.b(CONC, x, 0f, z, x + s * 1.5f, s, z + s);
        }
        pole(L, 3f, 31f, 6f, true);
        pole(L, 37f, 31f, 6f, true);
        pole(L, -10f, 46f, 6f, true);
        pole(L, 50f, 46f, 6f, true);
        pole(L, 20f, 56f, 6f, true);
    }

    // ------------------------------------------------------------------ estructura

    static void shell(Level L) {
        L.box(TILE, CONC, CONC, 0f, -0.2f, 0f, 40f, F0, 24f, true);
        L.slab(C0, F1, CARPET, CEIL, -0.15f, -0.15f, 40.15f, 24.15f, new float[]{1f, 3.4f, 4f, 9.4f});
        L.slab(C1, F2, ROOFTOP, CEIL, -0.15f, -0.15f, 40.15f, 24.15f, new float[]{31.4f, 10.5f, 37.4f, 13.5f});

        // muros exteriores del lobby
        L.wx(CONC, WALL, 1f, 0f, -0.15f, 40.15f, F0, C0);
        L.wxo(CONC, WALL, -1f, 24f, -0.15f, 40.15f, F0, C0,
                new float[][]{{4f, 13f, 0.9f, 2.8f}, {17f, 23f, F0, 2.9f}, {27f, 36f, 0.9f, 2.8f}}, true);
        L.wz(CONC, WALL, 1f, 0f, -0.15f, 24.15f, F0, C0);
        L.wz(CONC, WALL, -1f, 40f, -0.15f, 24.15f, F0, C0);
    }

    // ------------------------------------------------------------------ lobby

    static void couch(Level L, float cx, float cz, boolean alongX, float backDir, int mat) {
        bl(L, mat, cx, cz, alongX, -1f, -0.45f, 1f, 0.45f, F0, 0.5f);
        bl(L, mat, cx, cz, alongX, -1f, backDir * 0.25f, 1f, backDir * 0.45f, 0.5f, 1.0f);
        bl(L, mat, cx, cz, alongX, -1f, -0.45f, -0.85f, 0.45f, 0.5f, 0.75f);
        bl(L, mat, cx, cz, alongX, 0.85f, -0.45f, 1f, 0.45f, 0.5f, 0.75f);
    }

    static void plant(Level L, float x, float z) {
        L.b(BLACK, x - 0.25f, F0, z - 0.25f, x + 0.25f, 0.55f, z + 0.25f);
        L.b(GREEN, x - 0.4f, 0.55f, z - 0.4f, x + 0.4f, 1.55f, z + 0.4f);
    }

    static void lobby(Level L, Random rnd) {
        // pilares
        float[][] pil = {{14f, 7f}, {14f, 17f}, {26f, 17f}, {26f, 7f}};
        for (float[] p : pil) L.b(CONC, p[0] - 0.35f, F0, p[1] - 0.35f, p[0] + 0.35f, C0, p[1] + 0.35f);

        // recepcion
        L.b(WOOD, 24f, F0, 4f, 35f, 1.1f, 5.4f);
        L.b(BLACK, 23.8f, 1.1f, 3.8f, 35.2f, 1.16f, 5.6f);
        L.b(WOOD, 24f, F0, 0.15f, 35f, 2.6f, 0.6f);
        L.b(RED, 29.2f, 1.16f, 4.5f, 29.8f, 1.3f, 4.9f); // boton de alarma
        L.light(29.5f, 1.9f, 4.7f, 1.0f, 0.1f, 0.05f, 3.8f, 2);

        // ascensor (decorativo)
        L.b(METAL, 39.4f, F0, 9.5f, 39.85f, 2.7f, 14.5f);
        L.nb(BLACK, 39.36f, F0, 11.97f, 39.4f, 2.7f, 12.03f);
        L.nb(RED, 39.36f, 2.85f, 11.6f, 39.4f, 3.0f, 12.4f);

        // zonas de descanso
        couch(L, 8f, 21f, true, 1f, FABRIC1);
        couch(L, 8f, 16.5f, true, -1f, FABRIC1);
        L.b(WOOD, 7.5f, F0, 18.4f, 8.5f, 0.45f, 19.1f);
        couch(L, 33f, 19f, true, 1f, FABRIC2);
        couch(L, 33f, 14.5f, true, -1f, FABRIC2);
        L.b(WOOD, 32.5f, F0, 16f, 33.5f, 0.45f, 16.7f);
        couch(L, 20f, 8f, true, -1f, FABRIC2);
        plant(L, 1.2f, 22.8f);
        plant(L, 38.8f, 22.8f);
        plant(L, 12f, 1.2f);
        plant(L, 22f, 1.2f);

        // carrito de equipaje y maletas
        L.b(METAL, 17.5f, 0.2f, 14.7f, 18.5f, 0.25f, 15.3f);
        L.b(METAL, 17.5f, 0.25f, 14.7f, 17.58f, 1.4f, 15.3f);
        L.b(METAL, 18.42f, 0.25f, 14.7f, 18.5f, 1.4f, 15.3f);
        L.b(FABRIC2, 17.6f, 0.25f, 14.8f, 18.3f, 0.8f, 15.2f);

        // barricada parcial en la puerta principal
        L.b(FABRIC1, 16.1f, F0, 22.2f, 18.7f, 0.95f, 23.1f);
        L.b(WOOD, 21.8f, F0, 22.4f, 22.9f, 0.9f, 23.2f);

        // escombros y sangre
        for (int i = 0; i < 16; i++) {
            float x = 6f + rnd.nextFloat() * 31f, z = 7f + rnd.nextFloat() * 15f;
            float w = 0.3f + rnd.nextFloat() * 0.5f;
            int m = rnd.nextInt(3) == 0 ? METAL : (rnd.nextBoolean() ? WOOD : WHITE);
            L.b(m, x, F0, z, x + w, F0 + 0.1f + rnd.nextFloat() * 0.3f, z + w * 0.8f);
        }
        float[][] bl = {{11f, 9f, 2f, 1.5f}, {22f, 13f, 3f, 2f}, {30f, 6.5f, 1.5f, 1f}, {16f, 19f, 2.5f, 1.2f}, {4f, 14f, 1.4f, 1.6f}, {33f, 9f, 2f, 2.4f}};
        for (float[] b : bl) L.nb(BLOOD, b[0], F0, b[1], b[0] + b[2], F0 + 0.012f, b[1] + b[3]);

        // iluminacion del lobby
        float[][] lamps = {{8f, 6f}, {20f, 6f}, {32f, 6f}, {8f, 18f}, {20f, 18f}, {32f, 18f}};
        for (int i = 0; i < lamps.length; i++) {
            float x = lamps[i][0], z = lamps[i][1];
            boolean dead = (i == 3);
            L.nb(dead ? BLACK : LAMP, x - 0.45f, C0 - 0.08f, z - 0.45f, x + 0.45f, C0, z + 0.45f);
            if (!dead) L.light(x, C0 - 0.5f, z, 1.0f, 0.84f, 0.6f, 11f, (i == 4 || i == 2) ? 1 : 0);
        }
        L.light(3f, 2.5f, 12f, 1.0f, 0.12f, 0.05f, 7f, 2);  // emergencia en la escalera
    }

    // ------------------------------------------------------------------ piso 1

    static float zz(boolean north, float z) { return north ? z : 24f - z; }

    static void room(Level L, float cx, boolean north, int variant) {
        float y = F1;
        // cama
        L.b(WOOD, cx - 1.0f, y, zz(north, 0.2f), cx + 1.0f, y + 0.4f, zz(north, 2.4f));
        L.b(WHITE, cx - 0.95f, y + 0.4f, zz(north, 0.25f), cx + 0.95f, y + 0.65f, zz(north, 2.35f));
        L.b(WHITE, cx - 0.7f, y + 0.65f, zz(north, 0.3f), cx + 0.7f, y + 0.77f, zz(north, 0.8f));
        L.b(variant % 2 == 0 ? FABRIC1 : FABRIC2, cx - 0.95f, y + 0.65f, zz(north, 1.0f), cx + 0.95f, y + 0.73f, zz(north, 2.35f));
        L.b(WOOD, cx - 1.0f, y + 0.4f, zz(north, 0.15f), cx + 1.0f, y + 1.2f, zz(north, 0.3f));
        // mesita y lampara
        L.b(WOOD, cx + 1.2f, y, zz(north, 0.2f), cx + 1.8f, y + 0.55f, zz(north, 0.8f));
        L.nb(LAMP, cx + 1.35f, y + 0.55f, zz(north, 0.35f), cx + 1.65f, y + 0.8f, zz(north, 0.65f));
        // armario
        L.b(WOOD, cx + 2.9f, y, zz(north, 3.0f), cx + 3.85f, y + 2.2f, zz(north, 4.8f));
        // escritorio, silla y tele
        L.b(WOOD, cx - 3.85f, y, zz(north, 3.0f), cx - 3.1f, y + 0.75f, zz(north, 5.0f));
        L.b(BLACK, cx - 3.8f, y + 0.75f, zz(north, 3.6f), cx - 3.7f, y + 1.3f, zz(north, 4.4f));
        L.b(FABRIC2, cx - 2.7f, y, zz(north, 3.7f), cx - 2.2f, y + 0.5f, zz(north, 4.3f));
        // lampara de techo
        boolean dead = variant == 3;
        L.nb(dead ? BLACK : LAMP, cx - 0.3f, C1 - 0.08f, zz(north, 4.7f), cx + 0.3f, C1, zz(north, 5.3f));
        if (!dead) L.light(cx, C1 - 0.6f, zz(north, 5f), 1.0f, 0.82f, 0.55f, 7.5f, variant == 1 ? 1 : 0);
        // variantes
        if (variant == 1) L.nb(BLOOD, cx - 1.8f, y, zz(north, 3.4f), cx + 0.4f, y + 0.012f, zz(north, 5.8f));
        if (variant == 2) {
            L.b(WOOD, cx - 0.8f, y, zz(north, 6.0f), cx + 0.8f, y + 0.6f, zz(north, 6.8f)); // mesa volcada
            L.nb(BLOOD, cx + 1.0f, y, zz(north, 2.8f), cx + 2.4f, y + 0.012f, zz(north, 4.0f));
        }
        if (variant == 0) L.nb(BLOOD, cx + 0.2f, y, zz(north, 7.6f), cx + 1.2f, y + 0.012f, zz(north, 9.4f));
    }

    static void floor1(Level L) {
        float ya = F1, yb = C1, dh = F1 + 2.5f;
        float[][] win = {{2f, 6f, 5.0f, 6.9f}, {10f, 14f, 5.0f, 6.9f}, {18f, 22f, 5.0f, 6.9f}, {26f, 30f, 5.0f, 6.9f}};
        L.wxo(CONC, WALL, 1f, 0f, -0.15f, 40.15f, ya, yb, win, true);
        L.wxo(CONC, WALL, -1f, 24f, -0.15f, 40.15f, ya, yb, win, true);
        L.wz(CONC, WALL, 1f, 0f, -0.15f, 24.15f, ya, yb);
        L.wz(CONC, WALL, -1f, 40f, -0.15f, 24.15f, ya, yb);

        // paredes del pasillo (z=10 norte, z=14 sur) con puertas
        L.wxo(WALL, -1, 0f, 10f, 0f, 40f, ya, yb,
                new float[][]{{1f, 4f, ya, F1 + 2.7f}, {11.3f, 12.7f, ya, dh}, {19.3f, 20.7f, ya, dh}, {27.3f, 28.7f, ya, dh}}, false);
        L.wxo(WALL, -1, 0f, 14f, 0f, 40f, ya, yb,
                new float[][]{{3.3f, 4.7f, ya, dh}, {11.3f, 12.7f, ya, dh}, {19.3f, 20.7f, ya, dh}, {27.3f, 28.7f, ya, dh}}, false);
        float[] div = {8f, 16f, 24f, 32f};
        for (float x : div) {
            L.wz(WALL, -1, 0f, x, 0f, 10f, ya, yb);
            L.wz(WALL, -1, 0f, x, 14f, 24f, ya, yb);
        }

        // escaleras: lobby <-> piso 1 (corre en Z) y piso 1 <-> azotea (corre en X)
        L.stairsZ(9.4f, -1f, 1f, 4f, F1, F0, 15);
        L.stairsX(37.4f, -1f, 10.5f, 13.5f, F2, F1, 15);

        // cuartos
        room(L, 12f, true, 0);
        room(L, 20f, true, 1);
        room(L, 28f, true, 2);
        room(L, 4f, false, 3);
        room(L, 12f, false, 1);
        room(L, 20f, false, 0);
        room(L, 28f, false, 2);

        // bloque de escalera (oeste, norte): barandas y marca de emergencia
        L.b(METAL, 4.1f, F1, 3.4f, 4.25f, F1 + 1.0f, 9.4f);
        L.b(METAL, 0.85f, F1, 3.4f, 1.0f, F1 + 1.0f, 9.4f);

        // pasillo: luces, carrito volcado, extintor, sangre
        float[] lx = {12f, 20f, 28f};
        for (int i = 0; i < 3; i++) {
            L.nb(i == 2 ? BLACK : LAMP, lx[i] - 0.5f, C1 - 0.08f, 11.5f, lx[i] + 0.5f, C1, 12.5f);
            if (i != 2) L.light(lx[i], C1 - 0.5f, 12f, 1.0f, 0.86f, 0.62f, 9f, i == 1 ? 1 : 0);
        }
        L.light(4f, C1 - 0.6f, 11.5f, 1.0f, 0.1f, 0.05f, 9f, 2);
        L.light(33f, C1 - 0.6f, 12f, 1.0f, 0.1f, 0.05f, 8f, 2);
        L.b(METAL, 22f, F1, 11.4f, 24f, F1 + 0.1f, 12.2f);
        L.b(METAL, 22f, F1 + 0.1f, 11.4f, 22.1f, F1 + 1.0f, 12.2f);
        L.b(FABRIC2, 22.2f, F1 + 0.1f, 11.5f, 23.4f, F1 + 0.6f, 12.1f);
        L.b(RED, 15.6f, F1 + 0.8f, 10.16f, 15.85f, F1 + 1.3f, 10.4f);
        L.nb(BLOOD, 14f, F1, 11f, 17f, F1 + 0.012f, 12.6f);
        L.nb(BLOOD, 25f, F1, 12f, 27f, F1 + 0.012f, 13.4f);
        plant(L, 38.5f, 11f);
        L.b(CONC, 38f, F1, 10.2f, 39.7f, F1 + 1.0f, 13.8f); // contenedor al fondo
    }

    // ------------------------------------------------------------------ azotea

    static void roof(Level L) {
        float y = F2;
        // parapetos
        L.b(CONC, -0.15f, y, -0.15f, 40.15f, y + 1.1f, 0.15f);
        L.b(CONC, -0.15f, y, 23.85f, 40.15f, y + 1.1f, 24.15f);
        L.b(CONC, -0.15f, y, -0.15f, 0.15f, y + 1.1f, 24.15f);
        L.b(CONC, 39.85f, y, -0.15f, 40.15f, y + 1.1f, 24.15f);

        // helipad
        L.nb(PADDARK, 4f, y, 6f, 16f, y + 0.015f, 18f);
        L.nb(YELLOW, 4f, y, 6f, 16f, y + 0.025f, 6.25f);
        L.nb(YELLOW, 4f, y, 17.75f, 16f, y + 0.025f, 18f);
        L.nb(YELLOW, 4f, y, 6f, 4.25f, y + 0.025f, 18f);
        L.nb(YELLOW, 15.75f, y, 6f, 16f, y + 0.025f, 18f);
        L.nb(YELLOW, 8.2f, y, 9.5f, 8.6f, y + 0.025f, 14.5f);
        L.nb(YELLOW, 11.4f, y, 9.5f, 11.8f, y + 0.025f, 14.5f);
        L.nb(YELLOW, 8.6f, y, 11.8f, 11.4f, y + 0.025f, 12.2f);
        float[][] pl = {{4f, 6f}, {16f, 6f}, {4f, 18f}, {16f, 18f}};
        for (float[] p : pl) {
            L.nb(AMBER, p[0] - 0.2f, y, p[1] - 0.2f, p[0] + 0.2f, y + 0.2f, p[1] + 0.2f);
            L.light(p[0], y + 0.5f, p[1], 1.0f, 0.6f, 0.15f, 7f, 0);
        }

        // equipos
        L.b(METAL, 18f, y, 2.5f, 21f, y + 1.4f, 5f);
        L.b(METAL, 24f, y, 2f, 26.5f, y + 1.2f, 4.5f);
        L.b(METAL, 6f, y, 20.5f, 8f, y + 0.9f, 22.5f);
        L.b(METAL, 27f, y, 17.5f, 30f, y + 3.2f, 20.5f);
        L.b(CONC, 2f, y, 2f, 3.6f, y + 3f, 3.6f);
        L.b(CONC, 33f, y, 3f, 35f, y + 0.8f, 5f);
        L.b(WOOD, 20f, y, 20f, 21.2f, y + 1.0f, 21.2f);
        L.b(WOOD, 21.2f, y, 20.4f, 22.2f, y + 0.7f, 21.4f);
        // antena con baliza roja
        L.b(BLACK, 35f, y, 7f, 35.2f, y + 9f, 7.2f);
        L.nb(RED, 34.9f, y + 9f, 6.9f, 35.3f, y + 9.3f, 7.3f);
        L.light(35.1f, y + 9.2f, 7.1f, 1.0f, 0.1f, 0.05f, 16f, 2);
        // reflectores
        float[][] fl = {{6f, 3.5f}, {6f, 20.5f}, {26f, 21f}, {26f, 3f}};
        for (float[] p : fl) {
            L.b(BLACK, p[0] - 0.1f, y, p[1] - 0.1f, p[0] + 0.1f, y + 4f, p[1] + 0.1f);
            L.nb(LAMP, p[0] - 0.5f, y + 4f, p[1] - 0.25f, p[0] + 0.5f, y + 4.12f, p[1] + 0.25f);
            L.light(p[0], y + 3.7f, p[1], 0.75f, 0.85f, 1.0f, 15f, p[0] == 26f && p[1] == 3f ? 1 : 0);
        }

        // casa de escaleras sobre el hueco (entrada por el sur, lado este)
        float hy = y + 2.6f;
        L.b(CONC, 30.85f, y, 9.85f, 39.75f, hy, 10.15f);
        L.b(CONC, 30.85f, y, 9.85f, 31.15f, hy, 14.15f);
        L.b(CONC, 39.45f, y, 9.85f, 39.75f, hy, 14.15f);
        L.wxo(CONC, -1, 0f, 14f, 30.85f, 39.75f, y, hy, new float[][]{{37.6f, 39.2f, y, y + 2.2f}}, false);
        L.b(CONC, 30.7f, hy, 9.7f, 39.9f, hy + 0.4f, 14.3f);
        L.nb(RED, 38f, hy - 0.1f, 11.7f, 38.6f, hy, 12.3f);
        L.light(35f, hy - 0.6f, 12f, 1.0f, 0.12f, 0.06f, 9f, 2);
        L.light(38.4f, hy - 0.7f, 11.6f, 0.9f, 0.85f, 0.7f, 5f, 0);
        // armario del hacha (decorativo)
        L.b(RED, 39.2f, y + 0.8f, 10.4f, 39.45f, y + 1.9f, 11.4f);
    }

    // ------------------------------------------------------------------ items y enemigos

    static void itemsAndSpawns(Level L) {
        L.pickup(4, 38.7f, F2 + 1.0f, 11.0f);      // hacha en la casa de escaleras
        L.pickup(0, 34f, F2 + 0.6f, 19f);          // botiquin en la azotea
        L.pickup(1, 33.5f, F2 + 0.5f, 16f);        // municion
        L.pickup(0, 12f, F1 + 0.8f, 2.0f);         // botiquin cuarto norte
        L.pickup(2, 12f, F1 + 1.0f, 21.3f);        // AK en cuarto sur (borde de la cama)
        L.pickup(1, 20f, F1 + 0.5f, 13.4f);        // municion pasillo
        L.pickup(1, 28f, F1 + 0.5f, 21f);
        L.pickup(3, 29.5f, F0 + 0.9f, 2.0f);       // escopeta tras la recepcion
        L.pickup(0, 2f, F0 + 0.5f, 22f);
        L.pickup(1, 36f, F0 + 0.5f, 21f);
        L.pickup(1, 24f, 0.5f, 33f);
        L.pickup(0, 14f, 0.5f, 31f);

        // azotea
        L.spawn(0, 4f, F2, 21f);
        L.spawn(1, 30f, F2, 5f);
        // piso 1
        L.spawn(0, 14f, F1, 12f);
        L.spawn(0, 24f, F1, 12.5f);
        L.spawn(1, 29f, F1, 11.5f);
        L.spawn(0, 12f, F1, 6f);
        L.spawn(0, 20f, F1, 5f);
        L.spawn(0, 28f, F1, 7f);
        L.spawn(0, 4f, F1, 19f);
        L.spawn(1, 12f, F1, 19f);
        L.spawn(0, 20f, F1, 18f);
        L.spawn(0, 28f, F1, 20f);
        // lobby
        L.spawn(0, 12f, F0, 10f);
        L.spawn(0, 20f, F0, 17f);
        L.spawn(1, 30f, F0, 14f);
        L.spawn(0, 34f, F0, 21f);
        L.spawn(0, 8f, F0, 19f);
        L.spawn(0, 28f, F0, 10f);
        L.spawn(0, 18f, F0, 3f);
        L.spawn(2, 35f, F0, 12f);                  // bruto cerca del ascensor
        // calle
        L.spawn(0, 10f, 0f, 32f);
        L.spawn(0, 30f, 0f, 37f);
        L.spawn(1, 22f, 0f, 50f);
        L.spawn(0, -5f, 0f, 40f);
        L.spawn(0, 50f, 0f, 36f);
        L.spawn(0, 40f, 0f, 50f);

        // puntos de aparicion de la horda (calle, fuera de vista)
        float[][] hs = {{-18f, 0f, 35f}, {58f, 0f, 35f}, {20f, 0f, 57f}, {-18f, 0f, 12f}, {58f, 0f, 12f},
                {5f, 0f, -15f}, {35f, 0f, -15f}, {-12f, 0f, 55f}, {55f, 0f, 55f}};
        for (float[] h : hs) L.hordeSpawns.add(h);
    }
}
