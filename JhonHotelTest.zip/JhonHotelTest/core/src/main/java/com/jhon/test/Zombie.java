package com.jhon.test;

import com.badlogic.gdx.math.Matrix4;

/** Infectado: caminante, corredor o bruto. IA simple: detecta por vista/ruido, persigue, usa escaleras por puntos de paso. */
public class Zombie extends Ent {
    public static final int WALKER = 0, RUNNER = 1, BRUTE = 2;

    // puntos de paso (x, z) de las escaleras, en orden de subida
    static final float[][][] LINKS = {
            {{2.5f, 2.0f}, {2.5f, 11.0f}},                    // lobby <-> piso 1
            {{30.0f, 12.0f}, {38.4f, 12.2f}, {38.4f, 15.5f}}  // piso 1 <-> azotea
    };

    public int type;
    public float hp, maxHp, chaseSpeed, dmg, scale;
    public boolean alive = true, chasing = false;
    public float yaw, anim, deadT, atkCd, atkWind = -1f, atkAnim, hitFlash;
    float groanT, senseT, stuckT, sideT, sideDir = 1f, wanderT, wanderYaw, progT, lastD = 999f;
    boolean wandering;
    int wpi, wpKey;
    float sr, sg, sb, pr, pg, pb, kr, kg, kb; // camisa, pantalon, piel

    static final float[][] SHIRTS = {{0.35f, 0.38f, 0.45f}, {0.45f, 0.15f, 0.12f}, {0.2f, 0.35f, 0.22f},
            {0.5f, 0.45f, 0.3f}, {0.25f, 0.25f, 0.3f}, {0.6f, 0.6f, 0.55f}, {0.12f, 0.18f, 0.3f}};
    static final float[][] PANTS = {{0.12f, 0.13f, 0.2f}, {0.2f, 0.18f, 0.14f}, {0.1f, 0.1f, 0.1f}, {0.25f, 0.2f, 0.12f}};

    static final Matrix4 mb = new Matrix4(), ml = new Matrix4(), mt = new Matrix4(), mh = new Matrix4(), ma = new Matrix4();

    public Zombie(int type, float x, float y, float z) {
        this.type = type;
        this.x = x; this.y = y; this.z = z;
        switch (type) {
            case RUNNER: hp = 45f; chaseSpeed = 4.2f; dmg = 6f; scale = 0.95f; break;
            case BRUTE: hp = 420f; chaseSpeed = 2.7f; dmg = 28f; scale = 1.45f; r = 0.45f; h = 2.3f; break;
            default: hp = 65f; chaseSpeed = 2.0f + Util.rnd(0f, 0.5f); dmg = 9f; scale = 1f + Util.rnd(-0.04f, 0.06f);
        }
        maxHp = hp;
        yaw = Util.rnd(0f, 360f);
        anim = Util.rnd(0f, 10f);
        groanT = Util.rnd(1f, 8f);
        wanderT = Util.rnd(0f, 3f);
        float[] s = SHIRTS[(int) Util.rnd(0, SHIRTS.length - 0.01f)];
        float[] p = PANTS[(int) Util.rnd(0, PANTS.length - 0.01f)];
        float k = Util.rnd(0.85f, 1.1f);
        sr = s[0]; sg = s[1]; sb = s[2];
        pr = p[0]; pg = p[1]; pb = p[2];
        kr = 0.58f * k; kg = 0.66f * k; kb = 0.52f * k;
        if (type == BRUTE) { sr = 0.18f; sg = 0.2f; sb = 0.16f; kr = 0.5f; kg = 0.58f; kb = 0.46f; }
        grounded = false;
    }

    public void wake(Game g) {
        if (chasing || !alive) return;
        chasing = true;
        Sfx.playAt(Sfx.groan[(int) Util.rnd(0, 2.99f)], x, y + 1.5f, z, 1.0f, Sfx.pitchVar(0.12f) * (type == BRUTE ? 0.7f : 1f));
        for (int i = 0; i < g.zombies.size(); i++) {
            Zombie o = g.zombies.get(i);
            if (o.alive && !o.chasing) {
                float dx = o.x - x, dz = o.z - z, dy = o.y - y;
                if (dx * dx + dz * dz < 36f && Math.abs(dy) < 2f) o.chasing = true;
            }
        }
    }

    /** Devuelve true si murio con este golpe. */
    public boolean damage(Game g, float amount) {
        if (!alive) return false;
        hp -= amount;
        hitFlash = 0.14f;
        if (!chasing) wake(g);
        if (hp <= 0f) {
            alive = false;
            deadT = 0f;
            chasing = false;
            return true;
        }
        return false;
    }

    public void update(Game g, float dt) {
        if (!alive) { deadT += dt; return; }
        Level L = g.level;
        Player p = g.player;
        anim += dt;
        if (hitFlash > 0f) hitFlash -= dt;
        if (atkCd > 0f) atkCd -= dt;
        if (atkAnim > 0f) atkAnim -= dt;
        float dx = p.x - x, dz = p.z - z, dy = p.y - y;
        float d = (float) Math.sqrt(dx * dx + dz * dz);
        senseT -= dt;
        groanT -= dt;

        if (!chasing) {
            if (senseT <= 0f) {
                senseT = 0.4f + Util.rnd(0f, 0.2f);
                if (!p.dead && Math.abs(dy) < 2.5f) {
                    if (d < 2.5f) wake(g);
                    else if (d < 14f) {
                        float ex = x, ey = y + 1.5f * scale, ez = z;
                        float tx = p.x - ex, ty = p.y + 1.5f - ey, tz = p.z - ez;
                        float dist = (float) Math.sqrt(tx * tx + ty * ty + tz * tz);
                        float t = L.rayDist(ex, ey, ez, tx / dist, ty / dist, tz / dist, dist);
                        if (t >= dist - 0.2f) wake(g);
                    }
                }
            }
            wanderT -= dt;
            if (wanderT <= 0f) {
                wanderT = Util.rnd(2f, 6f);
                wanderYaw = Util.rnd(0f, 360f);
                wandering = Math.random() < 0.45;
            }
            if (wandering) {
                yaw += Util.clamp(Util.angleDiff(yaw, wanderYaw), -90f * dt, 90f * dt);
                float sp = 0.5f * dt;
                moveXZ(L, (float) Math.sin(Math.toRadians(yaw)) * sp, (float) Math.cos(Math.toRadians(yaw)) * sp);
            }
            if (groanT <= 0f) {
                groanT = Util.rnd(7f, 15f);
                if (d < 22f) Sfx.playAt(Sfx.groan[(int) Util.rnd(0, 2.99f)], x, y + 1.5f, z, 0.45f, Sfx.pitchVar(0.1f));
            }
            vertical(L, dt);
            return;
        }

        // ---- persecucion
        float gx = p.x, gz = p.z;
        int zf = Util.floorOf(y), pf = Util.floorOf(p.y);
        if (zf != pf) {
            int link = Math.min(zf, pf);
            boolean up = pf > zf;
            int key = link * 2 + (up ? 1 : 0) + 1;
            if (key != wpKey) { wpKey = key; wpi = 0; }
            float[][] W = LINKS[link];
            int n = W.length;
            if (wpi < n) {
                int idx = up ? wpi : n - 1 - wpi;
                gx = W[idx][0];
                gz = W[idx][1];
                float ddx = gx - x, ddz = gz - z;
                if (ddx * ddx + ddz * ddz < 1.4f * 1.4f) wpi++;
            }
        } else {
            wpKey = 0;
            wpi = 0;
        }
        float tx = gx - x, tz = gz - z;
        float td = (float) Math.sqrt(tx * tx + tz * tz);
        float desired = (float) Math.toDegrees(Math.atan2(tx, tz));
        if (sideT > 0f) { sideT -= dt; desired += sideDir * 75f; }
        float turn = type == RUNNER ? 540f : 360f;
        yaw += Util.clamp(Util.angleDiff(yaw, desired), -turn * dt, turn * dt);

        boolean inRange = d < 1.15f * scale + 0.25f && Math.abs(dy) < 1.5f && zf == pf;
        float sp = inRange ? 0f : chaseSpeed;
        if (sp > 0f) {
            float vx = (float) Math.sin(Math.toRadians(yaw)) * sp * dt;
            float vz = (float) Math.cos(Math.toRadians(yaw)) * sp * dt;
            boolean moved = moveXZ(L, vx, vz);
            if (!moved) stuckT += dt; else stuckT = Math.max(0f, stuckT - dt);
            if (stuckT > 0.3f) { stuckT = 0f; sideT = 0.7f; sideDir = Math.random() < 0.5 ? -1f : 1f; }
            progT += dt;
            if (progT >= 1.5f) {
                if (lastD - td < 0.4f && td > 1.5f) { sideT = 1.2f; sideDir = Math.random() < 0.5 ? -1f : 1f; }
                lastD = td;
                progT = 0f;
            }
        }

        // separacion entre zombis
        for (int i = 0; i < g.zombies.size(); i++) {
            Zombie o = g.zombies.get(i);
            if (o == this || !o.alive) continue;
            float ox = x - o.x, oz = z - o.z;
            float dd = ox * ox + oz * oz;
            float minD = 0.65f * (scale + o.scale) * 0.5f;
            if (dd < minD * minD && dd > 0.0001f) {
                float len = (float) Math.sqrt(dd);
                float push = (minD - len) * 0.5f;
                moveXZ(L, ox / len * push, oz / len * push);
            }
        }

        // ataque
        if (atkWind >= 0f) {
            atkWind -= dt;
            if (atkWind < 0f) {
                if (!p.dead && d < 1.5f * scale + 0.3f && Math.abs(p.y - y) < 1.6f) g.hurtPlayer(dmg, x, z);
                atkWind = -1f;
            }
        } else if (inRange && atkCd <= 0f && !p.dead) {
            atkCd = type == BRUTE ? 1.5f : 1.0f;
            atkWind = 0.3f;
            atkAnim = 0.5f;
        }

        if (groanT <= 0f) {
            groanT = Util.rnd(2.5f, 6f);
            Sfx.playAt(Sfx.groan[(int) Util.rnd(0, 2.99f)], x, y + 1.5f, z, 0.8f, Sfx.pitchVar(0.12f) * (type == BRUTE ? 0.7f : 1f));
        }
        vertical(L, dt);
    }

    // ------------------------------------------------------------------ dibujo

    static void pt(Matrix4 m, float ox, float oy, float oz, float sx, float sy, float sz, float r, float g, float b) {
        Gfx.setColor(r, g, b);
        Gfx.box(m, ox, oy, oz, sx, sy, sz);
    }

    public void draw(Game g) {
        Gfx.setTex(g.level.tGrain);
        Gfx.setEmis(hitFlash > 0f ? 0.5f : 0f, 0f, 0f);
        mb.idt().translate(x, y, z).rotate(0, 1, 0, yaw);
        if (!alive) {
            float f = Util.clamp(deadT / 0.45f, 0f, 1f);
            mb.rotate(1, 0, 0, -88f * f);
            if (deadT > 10f) mb.translate(0f, 0f, -(deadT - 10f) * 0.4f);
        }
        mb.scale(scale, scale, scale);

        float w = type == BRUTE ? 1.4f : 1f;
        float sf = alive ? (chasing ? chaseSpeed * 0.9f : (wandering ? 0.5f : 0.15f)) : 0f;
        float ph = anim * sf * 2.6f;
        float swing = alive ? (float) Math.sin(ph) * Math.min(40f, 12f + sf * 9f) : 0f;
        float lean = alive ? (chasing ? 14f : 6f) : 0f;

        // piernas
        for (int s = -1; s <= 1; s += 2) {
            ml.set(mb).translate(s * 0.12f * w, 0.9f, 0f).rotate(1, 0, 0, s * swing);
            pt(ml, 0f, -0.45f, 0f, 0.19f * w, 0.9f, 0.22f * w, pr, pg, pb);
            pt(ml, 0f, -0.86f, 0.05f, 0.2f * w, 0.1f, 0.32f, 0.08f, 0.07f, 0.07f);
        }
        // torso
        mt.set(mb).translate(0f, 0.9f, 0f).rotate(1, 0, 0, lean + (alive ? (float) Math.sin(anim * 1.7f) * 3f : 0f));
        pt(mt, 0f, 0.35f, 0f, 0.46f * w, 0.7f, 0.26f * w, sr, sg, sb);
        Gfx.setColor(0.3f, 0.02f, 0.02f);
        Gfx.box(mt, 0.08f * w, 0.25f, 0.135f * w, 0.18f, 0.22f, 0.012f);
        Gfx.box(mt, -0.1f * w, 0.5f, -0.135f * w, 0.14f, 0.16f, 0.012f);
        // cabeza
        mh.set(mt).translate(0f, 0.74f, 0.02f).rotate(0, 0, 1, alive ? (float) Math.sin(anim * 1.3f) * 12f : 0f)
                .rotate(1, 0, 0, alive ? -lean * 0.5f : 0f);
        pt(mh, 0f, 0.13f, 0f, 0.22f, 0.26f, 0.24f, kr, kg, kb);
        pt(mh, 0f, 0.27f, -0.01f, 0.23f, 0.07f, 0.25f, 0.12f, 0.1f, 0.08f);
        Gfx.setEmis(0.7f, 0.6f, 0.1f);
        Gfx.setColor(0.05f, 0.05f, 0.02f);
        Gfx.box(mh, -0.05f, 0.17f, 0.122f, 0.04f, 0.03f, 0.02f);
        Gfx.box(mh, 0.05f, 0.17f, 0.122f, 0.04f, 0.03f, 0.02f);
        Gfx.setEmis(hitFlash > 0f ? 0.5f : 0f, 0f, 0f);
        pt(mh, 0f, 0.05f, 0.122f, 0.12f, 0.05f, 0.02f, 0.25f, 0.03f, 0.03f);
        // brazos extendidos hacia adelante
        float armRot = -80f + (alive ? (float) Math.sin(anim * 2.1f) * 8f : 0f);
        if (atkAnim > 0f) armRot = -105f + (float) Math.sin((0.5f - atkAnim) / 0.5f * Math.PI) * 35f;
        for (int s = -1; s <= 1; s += 2) {
            ma.set(mt).translate(s * 0.3f * w, 0.62f, 0f).rotate(1, 0, 0, armRot + s * 4f);
            pt(ma, 0f, -0.18f, 0f, 0.12f * w, 0.36f, 0.12f * w, sr, sg, sb);
            pt(ma, 0f, -0.52f, 0f, 0.1f * w, 0.32f, 0.1f * w, kr, kg, kb);
        }
        Gfx.setEmis(0f, 0f, 0f);
    }

    // cajas de impacto en mundo (para disparos)
    public float hitHead(float ox, float oy, float oz, float dx, float dy, float dz) {
        float s = scale;
        return Util.rayBox(ox, oy, oz, dx, dy, dz, x - 0.2f * s, y + 1.45f * s, z - 0.2f * s, x + 0.2f * s, y + 1.9f * s, z + 0.2f * s);
    }

    public float hitBody(float ox, float oy, float oz, float dx, float dy, float dz) {
        float s = scale;
        float bw = 0.32f * s * (type == BRUTE ? 1.2f : 1f);
        return Util.rayBox(ox, oy, oz, dx, dy, dz, x - bw, y, z - bw, x + bw, y + 1.45f * s, z + bw);
    }
}
