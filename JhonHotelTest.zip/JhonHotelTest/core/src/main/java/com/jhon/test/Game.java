package com.jhon.test;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.audio.Sound;
import com.badlogic.gdx.graphics.GL20;
import com.badlogic.gdx.graphics.PerspectiveCamera;
import com.badlogic.gdx.graphics.Pixmap;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.glutils.FrameBuffer;
import com.badlogic.gdx.math.Matrix4;
import com.badlogic.gdx.math.Vector3;

import java.util.ArrayList;

/** Logica principal: estados (intro, juego, muerte, victoria), combate, horda, rescate y render. */
public class Game {
    public static final int INTRO = 0, PLAY = 1, DEAD = 2, WIN = 3;
    public static final int MAX_ZOMBIES = 50;       // maximo de zombis vivos a la vez
    public static final float HORDE_TIME = 55f;     // segundos de alarma hasta que aterriza el rescate
    public static final float APPROACH = 18f;       // segundos que dura la llegada del helicoptero
    public static final float RENDER_SCALE = 0.8f;  // resolucion 3D (bajar a 0.6 en moviles lentos)
    static final float SENS = 0.18f;

    public Level level;
    public Player player;
    public final ArrayList<Zombie> zombies = new ArrayList<Zombie>();
    Particles parts = new Particles();
    Heli heli = new Heli();
    Hud hud;
    PerspectiveCamera cam, vmCam;
    FrameBuffer fbo;
    final Weapons.View view = new Weapons.View();
    final Matrix4 v2w = new Matrix4();
    final Matrix4 pbase = new Matrix4();
    final Vector3 tv = new Vector3(), tr = new Vector3(), tu = new Vector3();

    public int state = INTRO;
    public float stateT, time, introT, playTime, fade = 1f;
    public int kills;
    public String objective, subtitle, subtitleWho = "", prompt, message = "";
    public float messageT, hordeLeft = -1f;

    boolean alarmOn, heliCalled, heliLanded, wasFire;
    float spawnT;
    Level.Light muzzleLight, heliLight;
    long heliId = -1, windId = -1, alarmId = -1;
    int brutesSpawned;

    public Game() {
        Gfx.init();
        Sfx.init();
        level = new Level();
        player = new Player();
        cam = new PerspectiveCamera(72f, 16f, 9f);
        cam.near = 0.08f;
        cam.far = 140f;
        vmCam = new PerspectiveCamera(58f, 16f, 9f);
        vmCam.near = 0.02f;
        vmCam.far = 6f;
        muzzleLight = level.light(0, 0, 0, 1.0f, 0.8f, 0.5f, 9f, 4);
        heliLight = level.light(0, 0, 0, 0.9f, 0.95f, 1.0f, 24f, 4);
        muzzleLight.cur = 0f;
        heliLight.cur = 0f;
        hud = new Hud(this);
        Gdx.input.setInputProcessor(hud);
        resize(Gdx.graphics.getWidth(), Gdx.graphics.getHeight());
        windId = Sfx.wind.loop(0.25f);
        startGame(true);
    }

    public void resize(int w, int h) {
        if (w <= 0 || h <= 0) return;
        cam.viewportWidth = w;
        cam.viewportHeight = h;
        vmCam.viewportWidth = w;
        vmCam.viewportHeight = h;
        if (hud != null) hud.layout();
        if (fbo != null) { fbo.dispose(); fbo = null; }
        try {
            fbo = new FrameBuffer(Pixmap.Format.RGBA8888, Math.max(64, (int) (w * RENDER_SCALE)), Math.max(64, (int) (h * RENDER_SCALE)), true);
            fbo.getColorBufferTexture().setFilter(Texture.TextureFilter.Linear, Texture.TextureFilter.Linear);
        } catch (Exception e) {
            fbo = null; // se dibuja directo a la pantalla
        }
    }

    // ------------------------------------------------------------------ inicio / reinicio

    void stopLoops() {
        if (heliId >= 0) { Sfx.heli.stop(heliId); heliId = -1; }
        if (alarmId >= 0) { Sfx.alarm.stop(alarmId); alarmId = -1; }
    }

    void startGame(boolean withIntro) {
        stopLoops();
        player.reset(level);
        zombies.clear();
        for (Level.Spawn s : level.idleSpawns) zombies.add(new Zombie(s.type, s.x, s.y, s.z));
        for (Level.Pickup k : level.pickups) k.taken = false;
        alarmOn = false; heliCalled = false; heliLanded = false;
        hordeLeft = -1f; kills = 0; playTime = 0f; brutesSpawned = 0; spawnT = 2f;
        message = ""; messageT = 0f; prompt = null; subtitle = null;
        parts = new Particles();
        heli.x = level.padX; heli.y = level.padY; heli.z = level.padZ;
        heli.yaw = -90f; heli.pitch = 0f; heli.roll = 0f; heli.rotor = 0f; heli.rotorSpeed = 0f;
        heli.visible = withIntro;
        heliLight.cur = 0f;
        stateT = 0f;
        if (withIntro) {
            state = INTRO;
            introT = 0f;
            fade = 1f;
            heliId = Sfx.heli.loop(0.1f);
        } else {
            state = PLAY;
            fade = 0.6f;
        }
    }

    // ------------------------------------------------------------------ bucle

    public void frame() {
        float dt = Math.min(Gdx.graphics.getDeltaTime(), 1f / 30f);
        time += dt;
        stateT += dt;
        hud.poll();

        switch (state) {
            case INTRO: updateIntro(dt); break;
            case PLAY: updatePlay(dt); break;
            case DEAD:
                updateDead(dt);
                break;
            default:
                if (hud.tapEdge && stateT > 1.5f) startGame(false);
                break;
        }
        if (state != INTRO) {
            for (int i = zombies.size() - 1; i >= 0; i--) {
                Zombie z = zombies.get(i);
                if (state != WIN) z.update(this, dt);
                else z.deadT += 0f;
                if (!z.alive && z.deadT > 16f) zombies.remove(i);
            }
        }
        heli.update(dt);
        parts.update(dt);
        updateLights();
        if (messageT > 0f) messageT -= dt;
        if (messageT <= 0f) message = "";
        if (fade > 0f && state != INTRO) fade = Math.max(0f, fade - dt * 1.2f);

        renderWorld();
        hud.draw();
        hud.endFrame();
    }

    void say(String m) { message = m; messageT = 3.5f; }

    // ------------------------------------------------------------------ intro

    void sub(String who, String text) { subtitleWho = who; subtitle = text; }

    void updateIntro(float dt) {
        introT += dt;
        Player p = player;
        fade = Math.max(0f, 1f - introT / 1.6f);
        heli.rotorSpeed = Math.min(introT / 1.8f, 1f) * 1900f;
        float e = introT - 2.2f;
        if (e > 0f) {
            heli.y = level.padY + e * 2.2f + e * e * 0.9f;
            heli.x = level.padX - e * e * 1.6f;
            heli.z = level.padZ + e * e * 0.25f;
            heli.yaw = -90f - Math.min(e * 4f, 20f);
            heli.pitch = Math.min(e * 5f, 15f);
            heli.roll = Math.min(e * 2f, 6f);
        }
        float dx = heli.x - p.x, dz = heli.z - p.z, dy = heli.y + 1.2f - (p.y + 1.62f);
        float tyaw = (float) Math.toDegrees(Math.atan2(-dx, -dz));
        float hd = (float) Math.sqrt(dx * dx + dz * dz);
        float tp = (float) Math.toDegrees(Math.atan2(dy, hd));
        p.yaw += Util.angleDiff(p.yaw, tyaw) * Math.min(1f, dt * 4f);
        p.pitch += (tp - p.pitch) * Math.min(1f, dt * 4f);
        p.camY = p.y + 1.62f;

        subtitle = null;
        if (introT > 0.4f && introT < 2.4f) sub("PILOTO (radio)", "Se acabo el tiempo, Jhon. Despegamos!");
        else if (introT > 2.6f && introT < 4.6f) sub("JHON", "Espera! Todavia no he subido!");
        else if (introT > 5.0f && introT < 8.2f) sub("PILOTO (radio)", "Hay demasiados infectados. Busca la salida del hotel, volvere por ti.");
        else if (introT > 8.6f && introT < 11.0f) sub("JHON", "Genial... Muy bien, Jhon. Vamos a bajar de aqui.");

        updateHeliSound(1.2f);
        if (introT > 11.2f || (hud.tapEdge && introT > 3f)) {
            heli.visible = false;
            if (heliId >= 0) { Sfx.heli.stop(heliId); heliId = -1; }
            subtitle = null;
            state = PLAY;
            stateT = 0f;
            fade = 0f;
            p.pitch = 0f;
            p.yaw = level.startYaw;
            say("Objetivo: salir del hotel");
        }
    }

    void updateHeliSound(float gain) {
        if (heliId < 0 || !heli.visible) return;
        float dx = heli.x - cam.position.x, dy = heli.y - cam.position.y, dz = heli.z - cam.position.z;
        float d = (float) Math.sqrt(dx * dx + dy * dy + dz * dz) + 0.1f;
        float vol = Util.clamp(gain * 2.5f / (1f + d * 0.08f), 0f, 1f);
        float pan = Util.clamp((dx * Sfx.rx + dz * Sfx.rz) / d, -1f, 1f);
        Sfx.heli.setPan(heliId, pan, vol);
    }

    // ------------------------------------------------------------------ juego

    void updatePlay(float dt) {
        Player p = player;
        playTime += dt;
        p.hurtT = Math.max(0f, p.hurtT - dt);
        p.hitMarker = Math.max(0f, p.hitMarker - dt);

        // mirada
        p.yaw -= hud.lookDX * SENS;
        p.pitch = Util.clamp(p.pitch - hud.lookDY * SENS, -85f, 85f);
        if (p.yaw > 360f) p.yaw -= 360f;
        if (p.yaw < -360f) p.yaw += 360f;

        // movimiento
        float fx = p.dirX(), fz = p.dirZ();
        float rx = -fz, rz = fx;
        float mx = hud.moveX, my = hud.moveY;
        float speed = 4.3f;
        float dx = (fx * my + rx * mx) * speed * dt;
        float dz = (fz * my + rz * mx) * speed * dt;
        float ox = p.x, oz = p.z;
        p.moveXZ(level, dx, dz);
        if (hud.jumpEdge && p.grounded) { p.vy = 7.2f; p.grounded = false; }
        p.vertical(level, dt);
        float moved = (float) Math.sqrt((p.x - ox) * (p.x - ox) + (p.z - oz) * (p.z - oz));
        boolean walking = moved > 0.002f && p.grounded;
        p.bobAmt += ((walking ? 1f : 0f) - p.bobAmt) * Math.min(1f, dt * 8f);
        if (walking) {
            p.bobT += moved * 2.4f;
            p.stepDist += moved;
            if (p.stepDist > 2.0f) {
                p.stepDist = 0f;
                Sfx.play2d(Sfx.step[(int) (Math.random() * 1.99)], 0.5f);
            }
        }
        p.camY += (p.y + 1.62f - p.camY) * Math.min(1f, dt * 16f);

        // armas
        p.fireCd -= dt;
        p.recoil = Math.max(0f, p.recoil - dt * 7f);
        p.heat = Math.max(0f, p.heat - dt * 1.4f);
        p.flashT -= dt;
        p.pump = Math.max(0f, p.pump - dt * 1.4f);
        p.raise = Math.min(1f, p.raise + dt * 4.5f);
        if (hud.slotEdge >= 0 && hud.slotEdge < Weapons.COUNT) switchTo(hud.slotEdge);
        if (hud.flashEdge) p.flashlight = !p.flashlight;
        if (hud.reloadEdge) startReload();
        if (p.reloading) {
            p.reloadT -= dt;
            if (p.reloadT <= 0f) finishReload();
        }
        boolean fire = hud.fireHeld();
        if (fire && (Weapons.AUTO[p.cur] || !wasFire)) tryFire();
        wasFire = fire;
        if (p.swingT >= 0f) {
            p.swingT += dt / 0.55f;
            if (p.swingT >= 0.5f && !p.swingHit) { p.swingHit = true; axeHit(); }
            if (p.swingT >= 1f) p.swingT = -1f;
        }

        // interaccion: alarma de recepcion
        prompt = null;
        float ax = p.x - level.alarmX, az = p.z - level.alarmZ;
        boolean nearAlarm = !alarmOn && ax * ax + az * az < 2.6f * 2.6f && Math.abs(p.y - 0.05f) < 1.5f;
        if (nearAlarm) {
            prompt = "USAR: activar la alarma de recepcion";
            if (hud.useEdge) triggerAlarm();
        }

        updatePickups();
        updateObjective();
        updateHorde(dt);

        if (p.hp <= 0f && !p.dead) die();
    }

    void updateDead(float dt) {
        Player p = player;
        p.hurtT = 0.3f;
        p.camY += (p.y + 0.35f - p.camY) * Math.min(1f, dt * 3f);
        p.pitch += (-20f - p.pitch) * Math.min(1f, dt * 2f);
        p.flashT -= dt;
        p.recoil = 0f;
        if (hud.tapEdge && stateT > 1.2f) startGame(false);
    }

    void die() {
        player.dead = true;
        state = DEAD;
        stateT = 0f;
        prompt = null;
        subtitle = null;
        stopLoops();
        Sfx.play2d(Sfx.hurt, 1f);
    }

    public void hurtPlayer(float dmg, float fx, float fz) {
        Player p = player;
        if (p.dead || state != PLAY) return;
        p.hp -= dmg;
        p.hurtT = 0.7f;
        Sfx.play2d(Sfx.hurt, 0.8f);
        try { Gdx.input.vibrate(60); } catch (Exception ignored) { }
    }

    public int aliveCount() {
        int n = 0;
        for (int i = 0; i < zombies.size(); i++) if (zombies.get(i).alive) n++;
        return n;
    }

    /** Un ruido despierta a los zombis cercanos. */
    public void noise(float x, float y, float z, float radius) {
        float r2 = radius * radius;
        for (int i = 0; i < zombies.size(); i++) {
            Zombie zb = zombies.get(i);
            if (!zb.alive || zb.chasing) continue;
            float dx = zb.x - x, dy = zb.y - y, dz = zb.z - z;
            if (dx * dx + dy * dy * 4f + dz * dz < r2) zb.chasing = true;
        }
    }

    // ------------------------------------------------------------------ armas

    void switchTo(int w) {
        Player p = player;
        if (w == p.cur || !p.has[w]) return;
        p.cur = w;
        p.raise = 0f;
        p.reloading = false;
        p.swingT = -1f;
        p.fireCd = 0.25f;
    }

    void startReload() {
        Player p = player;
        int w = p.cur;
        if (w == Weapons.AXE || p.reloading || p.swingT >= 0f) return;
        if (p.mag[w] >= Weapons.MAG[w] || p.res[w] <= 0) return;
        p.reloading = true;
        p.reloadT = Weapons.RELOAD[w];
        Sfx.play2d(Sfx.reload, 0.7f);
    }

    void finishReload() {
        Player p = player;
        int w = p.cur;
        int take = Math.min(Weapons.MAG[w] - p.mag[w], p.res[w]);
        p.mag[w] += take;
        p.res[w] -= take;
        p.reloading = false;
    }

    void tryFire() {
        Player p = player;
        int w = p.cur;
        if (p.fireCd > 0f || p.reloading || p.raise < 0.8f) return;
        if (w == Weapons.AXE) {
            if (p.swingT >= 0f) return;
            p.swingT = 0f;
            p.swingHit = false;
            p.fireCd = Weapons.RATE[w];
            Sfx.play2d(Sfx.swing, 0.9f);
            return;
        }
        if (p.mag[w] <= 0) {
            Sfx.play2d(Sfx.empty, 0.7f);
            p.fireCd = 0.3f;
            if (p.res[w] > 0) startReload();
            return;
        }
        p.mag[w]--;
        p.fireCd = Weapons.RATE[w];
        p.flashT = 0.06f;
        p.recoil = 1f;
        float spread = Weapons.SPREAD[w] + (w == Weapons.AK ? p.heat * 2.4f : 0f);
        p.heat = Math.min(1f, p.heat + (w == Weapons.AK ? 0.12f : 0.25f));
        Sound snd = w == Weapons.PISTOL ? Sfx.pistol : (w == Weapons.AK ? Sfx.ak : Sfx.shotgun);
        Sfx.play2d(snd, 1f);
        int n = Math.max(1, Weapons.PELLETS[w]);
        for (int i = 0; i < n; i++) fireRay(spread, Weapons.DMG[w], Weapons.RANGE[w], w == Weapons.SHOTGUN);
        if (w == Weapons.SHOTGUN) p.pump = 1f;
        float kick = Weapons.KICK[w] * Util.rnd(0.7f, 1.1f);
        p.pitch = Math.min(85f, p.pitch + kick);
        p.yaw += Util.rnd(-0.35f, 0.35f) * kick;
        noise(p.x, p.y, p.z, w == Weapons.PISTOL ? 24f : (w == Weapons.AK ? 38f : 42f));
        if (p.mag[w] == 0 && p.res[w] > 0) startReload();
    }

    void fireRay(float spreadDeg, float dmg, float range, boolean falloff) {
        Player p = player;
        tv.set(cam.direction);
        tr.set(cam.direction).crs(cam.up).nor();
        tu.set(tr).crs(cam.direction).nor();
        float sx = (Util.rnd(-1f, 1f) + Util.rnd(-1f, 1f)) * 0.5f * spreadDeg;
        float sy = (Util.rnd(-1f, 1f) + Util.rnd(-1f, 1f)) * 0.5f * spreadDeg;
        float ax = (float) Math.tan(Math.toRadians(sx)), ay = (float) Math.tan(Math.toRadians(sy));
        float dx = tv.x + tr.x * ax + tu.x * ay;
        float dy = tv.y + tr.y * ax + tu.y * ay;
        float dz = tv.z + tr.z * ax + tu.z * ay;
        float len = (float) Math.sqrt(dx * dx + dy * dy + dz * dz);
        dx /= len; dy /= len; dz /= len;
        float ox = cam.position.x, oy = cam.position.y, oz = cam.position.z;

        float wallT = level.rayDist(ox, oy, oz, dx, dy, dz, range);
        Zombie best = null;
        float bestT = wallT;
        boolean bestHead = false;
        for (int i = 0; i < zombies.size(); i++) {
            Zombie z = zombies.get(i);
            if (!z.alive) continue;
            float ddx = z.x - ox, ddz = z.z - oz;
            if (ddx * ddx + ddz * ddz > range * range) continue;
            float th = z.hitHead(ox, oy, oz, dx, dy, dz);
            float tb = z.hitBody(ox, oy, oz, dx, dy, dz);
            float t = -1f;
            boolean head = false;
            if (th >= 0f && (tb < 0f || th <= tb + 0.3f)) { t = th; head = true; }
            else if (tb >= 0f) t = tb;
            if (t >= 0f && t < bestT) { best = z; bestT = t; bestHead = head; }
        }
        if (best != null) {
            float d = bestT;
            float dm = dmg * (bestHead ? (best.type == Zombie.BRUTE ? 1.6f : 3f) : 1f);
            if (falloff) dm *= Util.clamp(1.35f - d / 25f, 0.25f, 1f);
            boolean killed = best.damage(this, dm);
            parts.blood(level, ox + dx * d, oy + dy * d, oz + dz * d, -dx, -dy * 0.3f, -dz, bestHead ? 9 : 5);
            Sfx.playAt(Sfx.hit, best.x, best.y + 1f, best.z, 0.7f, Sfx.pitchVar(0.15f));
            p.hitMarker = 0.18f;
            if (killed) kills++;
        } else if (wallT < range) {
            parts.sparks(level, ox + dx * (wallT - 0.03f), oy + dy * (wallT - 0.03f), oz + dz * (wallT - 0.03f), -dx, -dy, -dz, 4);
        }
    }

    void axeHit() {
        Player p = player;
        float fx = p.dirX(), fz = p.dirZ();
        boolean hit = false;
        for (int i = 0; i < zombies.size(); i++) {
            Zombie z = zombies.get(i);
            if (!z.alive) continue;
            float dx = z.x - p.x, dz = z.z - p.z;
            float d = (float) Math.sqrt(dx * dx + dz * dz);
            if (d < Weapons.RANGE[Weapons.AXE] + 0.4f * z.scale && d > 0.001f && (dx * fx + dz * fz) / d > 0.55f
                    && Math.abs(z.y - p.y) < 1.8f) {
                boolean killed = z.damage(this, Weapons.DMG[Weapons.AXE]);
                parts.blood(level, z.x, z.y + 1.3f, z.z, -fx, 0.3f, -fz, 10);
                z.moveXZ(level, dx / d * 0.8f, dz / d * 0.8f);
                Sfx.playAt(Sfx.hit, z.x, z.y + 1f, z.z, 1f, 0.8f);
                if (killed) kills++;
                hit = true;
            }
        }
        if (hit) p.hitMarker = 0.2f;
        else {
            float t = level.rayDist(cam.position.x, cam.position.y, cam.position.z, cam.direction.x, cam.direction.y, cam.direction.z, 2.4f);
            if (t < 2.4f) {
                parts.sparks(level, cam.position.x + cam.direction.x * t, cam.position.y + cam.direction.y * t,
                        cam.position.z + cam.direction.z * t, -cam.direction.x, -cam.direction.y, -cam.direction.z, 6);
                Sfx.play2d(Sfx.empty, 0.8f);
            }
        }
        noise(p.x, p.y, p.z, 8f);
    }

    // ------------------------------------------------------------------ items

    void updatePickups() {
        Player p = player;
        for (Level.Pickup k : level.pickups) {
            if (k.taken) continue;
            float dx = k.x - p.x, dz = k.z - p.z;
            if (dx * dx + dz * dz > 1.8f * 1.8f || Math.abs((k.y - 0.8f) - p.y) > 1.6f) continue;
            boolean took = false;
            switch (k.type) {
                case 0:
                    if (p.hp < 100f) { p.hp = Math.min(100f, p.hp + 45f); say("+ Botiquin"); took = true; }
                    break;
                case 1: {
                    boolean any = false;
                    int[] add = {30, 60, 16, 0};
                    for (int w = 0; w < Weapons.COUNT; w++) {
                        if (p.has[w] && Weapons.MAXRES[w] > 0 && p.res[w] < Weapons.MAXRES[w]) {
                            p.res[w] = Math.min(Weapons.MAXRES[w], p.res[w] + add[w]);
                            any = true;
                        }
                    }
                    if (any) { say("+ Municion"); took = true; }
                    break;
                }
                case 2: took = giveGun(Weapons.AK, 90); break;
                case 3: took = giveGun(Weapons.SHOTGUN, 24); break;
                default:
                    if (!p.has[Weapons.AXE]) {
                        p.has[Weapons.AXE] = true;
                        switchTo(Weapons.AXE);
                        say("Hacha de bombero equipada (slot 4)");
                        took = true;
                    }
            }
            if (took) {
                k.taken = true;
                Sfx.play2d(Sfx.pickup, 0.8f);
            }
        }
    }

    boolean giveGun(int w, int reserve) {
        Player p = player;
        if (p.has[w]) {
            if (p.res[w] >= Weapons.MAXRES[w]) return false;
            p.res[w] = Math.min(Weapons.MAXRES[w], p.res[w] + reserve / 2);
            say("+ Municion " + Weapons.NAME[w]);
            return true;
        }
        p.has[w] = true;
        p.mag[w] = Weapons.MAG[w];
        p.res[w] = reserve;
        switchTo(w);
        say("Recogiste: " + Weapons.NAME[w]);
        return true;
    }

    // ------------------------------------------------------------------ objetivos, alarma y rescate

    void updateObjective() {
        Player p = player;
        int f = Util.floorOf(p.y);
        if (!alarmOn) {
            if (f == 2) objective = "Baja por la escalera de la azotea (extremo este)";
            else if (f == 1) objective = "Busca como bajar al lobby (escalera al oeste del pasillo)";
            else objective = "Activa la alarma en la recepcion para pedir rescate";
        } else if (!heliLanded) {
            objective = "Sobrevive hasta que llegue el helicoptero";
        } else {
            objective = "Corre al helicoptero en la calle!";
        }
    }

    void triggerAlarm() {
        alarmOn = true;
        hordeLeft = HORDE_TIME;
        spawnT = 0.5f;
        alarmId = Sfx.alarm.loop(0.3f);
        say("ALARMA ACTIVADA! Resiste hasta que llegue el rescate");
        noise(player.x, player.y, player.z, 90f);
    }

    void updateHorde(float dt) {
        if (!alarmOn) return;
        Player p = player;
        if (hordeLeft > 0f) hordeLeft -= dt;
        // aparicion de zombis (corren hacia el jugador)
        spawnT -= dt;
        if (spawnT <= 0f) {
            spawnT = heliLanded ? 1.1f : 0.55f;
            if (aliveCount() < MAX_ZOMBIES) spawnHorde();
        }
        // llegada del helicoptero
        if (!heliCalled && hordeLeft <= APPROACH) {
            heliCalled = true;
            heli.visible = true;
            heli.rotorSpeed = 1900f;
            heliId = Sfx.heli.loop(0.1f);
            say("Escuchas un helicoptero acercandose. Aguanta!");
        }
        if (heliCalled && !heliLanded) {
            float t = Util.clamp((APPROACH - Math.max(hordeLeft, 0f)) / APPROACH, 0f, 1f);
            float e = t * t * (3f - 2f * t);
            float x0 = 95f, z0 = 120f;
            heli.x = Util.lerp(x0, level.lzX, e);
            heli.z = Util.lerp(z0, level.lzZ, e);
            heli.y = 45f * (1f - t) * (1f - t);
            heli.yaw = (float) Math.toDegrees(Math.atan2(level.lzX - x0, level.lzZ - z0));
            heli.pitch = 12f * (1f - t);
            heli.roll = 0f;
            heliLight.x = heli.x; heliLight.y = heli.y + 1.2f; heliLight.z = heli.z;
            heliLight.cur = 1f;
            if (t >= 1f) {
                heliLanded = true;
                heli.pitch = 0f;
                hordeLeft = -1f;
                say("El helicoptero aterrizo! Corre hacia el!");
            }
        }
        if (heliLanded) {
            heliLight.x = heli.x; heliLight.y = heli.y + 3f; heliLight.z = heli.z;
            float dx = p.x - level.lzX, dz = p.z - level.lzZ;
            if (dx * dx + dz * dz < 7f * 7f && p.y < 2f && !p.dead) {
                state = WIN;
                stateT = 0f;
                prompt = null;
                stopLoops();
            }
        }
        updateHeliSound(1f);
    }

    void spawnHorde() {
        Player p = player;
        for (int tries = 0; tries < 6; tries++) {
            float[] s = level.hordeSpawns.get((int) (Math.random() * level.hordeSpawns.size()));
            float dx = s[0] - p.x, dz = s[2] - p.z;
            if (dx * dx + dz * dz < 20f * 20f) continue;
            float r = (float) Math.random();
            int type = r < 0.70f ? Zombie.WALKER : (r < 0.93f ? Zombie.RUNNER : Zombie.BRUTE);
            if (type == Zombie.BRUTE) {
                if (brutesSpawned >= 2) type = Zombie.WALKER; else brutesSpawned++;
            }
            Zombie z = new Zombie(type, s[0] + Util.rnd(-2f, 2f), s[1], s[2] + Util.rnd(-2f, 2f));
            z.chasing = true;
            zombies.add(z);
            return;
        }
    }

    // ------------------------------------------------------------------ luces

    void updateLights() {
        float t = time;
        Player p = player;
        muzzleLight.cur = p.flashT > 0f && state == PLAY ? 1f : 0f;
        muzzleLight.x = cam.position.x + cam.direction.x * 0.8f;
        muzzleLight.y = cam.position.y + cam.direction.y * 0.8f;
        muzzleLight.z = cam.position.z + cam.direction.z * 0.8f;

        float cx = cam.position.x, cy = cam.position.y, cz = cam.position.z;
        int n = Gfx.NL;
        float[] bestScore = new float[n];
        Level.Light[] pick = new Level.Light[n];
        float[] pick_i = new float[n];
        for (int i = 0; i < n; i++) bestScore[i] = Float.MAX_VALUE;
        for (int i = 0, c = level.lights.size(); i < c; i++) {
            Level.Light l = level.lights.get(i);
            float inten;
            switch (l.mode) {
                case 1: {
                    float f = (float) (Math.sin(t * 37f + l.phase) * Math.sin(t * 13.7f + l.phase * 2f));
                    inten = Math.sin(t * 2.3f + l.phase) > 0.92 ? 0f : (f > 0.6f ? 0.25f : 1f);
                    break;
                }
                case 2: inten = 0.15f + 0.85f * (0.5f + 0.5f * (float) Math.sin(t * 3.2f + l.phase)); break;
                case 3: inten = 0f; break;
                case 4: inten = l.cur; break;
                default: inten = 1f;
            }
            if (inten <= 0.01f) continue;
            float dx = l.x - cx, dy = l.y - cy, dz = l.z - cz;
            float d2 = dx * dx + dy * dy + dz * dz;
            if (d2 > (l.rad + 6f) * (l.rad + 6f) && l.mode != 4) continue;
            float score = d2 / (l.rad * l.rad * inten);
            if (l.mode == 4 && l.rad > 20f) score *= 0.2f;
            // insertar ordenado
            for (int k = 0; k < n; k++) {
                if (score < bestScore[k]) {
                    for (int m = n - 1; m > k; m--) { bestScore[m] = bestScore[m - 1]; pick[m] = pick[m - 1]; pick_i[m] = pick_i[m - 1]; }
                    bestScore[k] = score; pick[k] = l; pick_i[k] = inten;
                    break;
                }
            }
        }
        for (int k = 0; k < n; k++) {
            Level.Light l = pick[k];
            if (l == null) {
                Gfx.lp[k * 3] = 0f; Gfx.lp[k * 3 + 1] = -500f; Gfx.lp[k * 3 + 2] = 0f;
                Gfx.lc[k * 3] = 0f; Gfx.lc[k * 3 + 1] = 0f; Gfx.lc[k * 3 + 2] = 0f;
                Gfx.lr[k] = 0.01f;
            } else {
                Gfx.lp[k * 3] = l.x; Gfx.lp[k * 3 + 1] = l.y; Gfx.lp[k * 3 + 2] = l.z;
                float s = pick_i[k] * 1.15f;
                Gfx.lc[k * 3] = l.r * s; Gfx.lc[k * 3 + 1] = l.g * s; Gfx.lc[k * 3 + 2] = l.b * s;
                Gfx.lr[k] = l.rad;
            }
        }
    }

    // ------------------------------------------------------------------ dibujo

    void setupCamera() {
        Player p = player;
        double yr = Math.toRadians(p.yaw), pr = Math.toRadians(p.pitch);
        float cp = (float) Math.cos(pr);
        cam.position.set(p.x, p.camY, p.z);
        cam.direction.set((float) -Math.sin(yr) * cp, (float) Math.sin(pr), (float) -Math.cos(yr) * cp).nor();
        cam.up.set(0f, 1f, 0f);
        if (state == DEAD) cam.up.set((float) Math.sin(Math.min(stateT, 1.2f)) * 0.5f, 1f, 0f).nor();
        cam.update();
        Sfx.lx = cam.position.x; Sfx.ly = cam.position.y; Sfx.lz = cam.position.z;
        Sfx.rx = (float) Math.cos(yr); Sfx.rz = (float) -Math.sin(yr);
    }

    void drawPickup(Level.Pickup k) {
        float bob = (float) Math.sin(time * 2f + k.x) * 0.06f;
        pbase.idt().translate(k.x, k.y + bob, k.z).rotate(0, 1, 0, time * 55f + k.z * 20f);
        Gfx.setTex(level.tGrain);
        Gfx.setEmis(0.14f, 0.14f, 0.12f);
        switch (k.type) {
            case 0:
                Gfx.setColor(0.85f, 0.85f, 0.85f);
                Gfx.box(pbase, 0f, 0f, 0f, 0.36f, 0.22f, 0.26f);
                Gfx.setColor(0.8f, 0.05f, 0.05f);
                Gfx.setEmis(0.5f, 0f, 0f);
                Gfx.box(pbase, 0f, 0f, 0f, 0.2f, 0.06f, 0.27f);
                Gfx.box(pbase, 0f, 0f, 0f, 0.06f, 0.2f, 0.27f);
                break;
            case 1:
                Gfx.setColor(0.28f, 0.32f, 0.16f);
                Gfx.box(pbase, 0f, 0f, 0f, 0.38f, 0.22f, 0.26f);
                Gfx.setColor(0.8f, 0.65f, 0.1f);
                Gfx.box(pbase, 0f, 0f, 0f, 0.1f, 0.23f, 0.27f);
                break;
            case 2:
                Gfx.setColor(0.15f, 0.15f, 0.16f);
                Gfx.box(pbase, 0f, 0f, 0f, 0.06f, 0.09f, 0.8f);
                Gfx.setColor(0.6f, 0.38f, 0.2f);
                Gfx.box(pbase, 0f, -0.02f, 0.5f, 0.05f, 0.1f, 0.3f);
                Gfx.box(pbase, 0f, -0.01f, -0.3f, 0.07f, 0.06f, 0.25f);
                Gfx.setColor(0.1f, 0.1f, 0.1f);
                Gfx.box(pbase, 0f, -0.12f, -0.05f, 0.04f, 0.16f, 0.07f);
                break;
            case 3:
                Gfx.setColor(0.13f, 0.13f, 0.14f);
                Gfx.box(pbase, 0f, 0.02f, -0.1f, 0.05f, 0.05f, 0.95f);
                Gfx.setColor(0.6f, 0.38f, 0.2f);
                Gfx.box(pbase, 0f, -0.02f, 0.5f, 0.06f, 0.11f, 0.35f);
                Gfx.box(pbase, 0f, -0.03f, -0.2f, 0.07f, 0.06f, 0.22f);
                break;
            default:
                Gfx.setColor(0.5f, 0.32f, 0.17f);
                Gfx.box(pbase, 0f, 0f, 0f, 0.05f, 0.05f, 0.8f);
                Gfx.setColor(0.7f, 0.7f, 0.75f);
                Gfx.box(pbase, 0f, 0.01f, -0.38f, 0.05f, 0.18f, 0.22f);
                Gfx.setColor(0.7f, 0.05f, 0.05f);
                Gfx.box(pbase, 0f, 0f, 0.3f, 0.06f, 0.06f, 0.2f);
        }
        Gfx.setEmis(0f, 0f, 0f);
    }

    void renderWorld() {
        setupCamera();
        updateHeliSound(state == INTRO ? 1.2f : 1f);
        boolean useFbo = fbo != null;
        if (useFbo) fbo.begin();
        Gdx.gl.glClearColor(0.035f, 0.045f, 0.08f, 1f);
        Gdx.gl.glClear(GL20.GL_COLOR_BUFFER_BIT | GL20.GL_DEPTH_BUFFER_BIT);
        Gdx.gl.glDisable(GL20.GL_BLEND);

        Gfx.begin(cam.combined, cam.position.x, cam.position.y, cam.position.z,
                0.11f, 0.13f, 0.19f, 0.035f, 0.045f, 0.08f, 0.022f);
        Player p = player;
        boolean spotOn = p.flashlight && state != INTRO && !p.dead;
        Gfx.setSpot(cam.position.x + cam.direction.x * 0.1f, cam.position.y - 0.08f, cam.position.z + cam.direction.z * 0.1f,
                cam.direction.x, cam.direction.y, cam.direction.z, spotOn);

        level.render();
        for (Level.Pickup k : level.pickups) if (!k.taken) drawPickup(k);
        for (int i = 0; i < zombies.size(); i++) {
            Zombie z = zombies.get(i);
            float dx = z.x - cam.position.x, dz = z.z - cam.position.z;
            if (dx * dx + dz * dz > 70f * 70f) continue;
            if (!cam.frustum.sphereInFrustum(z.x, z.y + 1f, z.z, 2.4f * z.scale)) continue;
            z.draw(this);
        }
        parts.draw();
        heli.draw(level);

        // arma en primera persona (con su propia perspectiva y sin niebla)
        if (state == PLAY || state == WIN) {
            Gdx.gl.glClear(GL20.GL_DEPTH_BUFFER_BIT);
            vmCam.position.set(cam.position);
            vmCam.direction.set(cam.direction);
            vmCam.up.set(cam.up);
            vmCam.update();
            v2w.set(cam.view).inv();
            Gfx.setProj(vmCam.combined, true);
            view.bobX = (float) Math.sin(p.bobT) * 0.012f * p.bobAmt;
            view.bobY = (float) Math.abs(Math.cos(p.bobT)) * 0.014f * p.bobAmt;
            view.recoil = p.recoil;
            view.reloadP = p.reloading ? 1f - p.reloadT / Weapons.RELOAD[p.cur] : -1f;
            view.swingP = p.swingT;
            view.raise = p.raise;
            view.flash = p.flashT > 0f ? p.flashT / 0.06f : 0f;
            view.pump = 1f - p.pump;
            Weapons.draw(v2w, p.cur, view, level);
            Gfx.setProj(cam.combined, false);
        }
        if (useFbo) {
            fbo.end();
            Gdx.gl.glViewport(0, 0, Gdx.graphics.getBackBufferWidth(), Gdx.graphics.getBackBufferHeight());
            Gdx.gl.glClearColor(0f, 0f, 0f, 1f);
            Gdx.gl.glClear(GL20.GL_COLOR_BUFFER_BIT);
            Texture t = fbo.getColorBufferTexture();
            hud.sb.setProjectionMatrix(hud.cam.combined);
            hud.sb.begin();
            hud.sb.disableBlending();
            hud.sb.draw(t, 0f, 0f, hud.W, Hud.H, 0, 0, t.getWidth(), t.getHeight(), false, true);
            hud.sb.enableBlending();
            hud.sb.end();
        }
    }

    public void dispose() {
        stopLoops();
        if (windId >= 0) Sfx.wind.stop(windId);
        hud.dispose();
        if (fbo != null) fbo.dispose();
    }
}
