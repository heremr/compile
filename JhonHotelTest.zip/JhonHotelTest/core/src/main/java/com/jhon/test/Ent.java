package com.jhon.test;

/** Cuerpo con fisica simple (cilindro/caja) usado por el jugador y los zombis. */
public class Ent {
    public float x, y, z, vy;
    public float r = 0.3f, h = 1.75f;
    public boolean grounded;

    static final float GRAV = 22f;
    static final float MAXFALL = -15f;

    /** Mueve en X y Z por separado (deslizamiento contra paredes). Devuelve true si se movio algo. */
    public boolean moveXZ(Level L, float dx, float dz) {
        boolean moved = false;
        if (dx != 0f && !L.blocked(x + dx, y, z, r, h)) { x += dx; moved = true; }
        if (dz != 0f && !L.blocked(x, y, z + dz, r, h)) { z += dz; moved = true; }
        return moved;
    }

    public void vertical(Level L, float dt) {
        float g = L.groundAt(x, y, z, r);
        if (grounded && vy <= 0f) {
            if (g > -50f && g >= y - 0.6f) {
                y = g;
                vy = 0f;
                return;
            }
            grounded = false;
        }
        vy -= GRAV * dt;
        if (vy < MAXFALL) vy = MAXFALL;
        y += vy * dt;
        if (vy > 0f && L.blocked(x, y, z, r, h)) {
            y -= vy * dt;
            vy = 0f;
        }
        g = L.groundAt(x, y, z, r);
        if (vy <= 0f && g > -50f && y <= g) {
            y = g;
            vy = 0f;
            grounded = true;
        } else {
            grounded = false;
        }
        if (y < -30f) { y = 0f; vy = 0f; }
    }
}
