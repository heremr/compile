package com.jhon.test;

import com.badlogic.gdx.math.Matrix4;

/** Estadisticas de armas y modelos en primera persona (hechos con cajas, sin archivos externos). */
public class Weapons {
    public static final int PISTOL = 0, AK = 1, SHOTGUN = 2, AXE = 3, COUNT = 4;

    public static final String[] NAME = {"PISTOLA 9MM", "AK-47", "ESCOPETA", "HACHA"};
    public static final float[] DMG = {30f, 24f, 13f, 75f};
    public static final float[] RATE = {0.17f, 0.095f, 0.95f, 0.62f};
    public static final int[] MAG = {15, 30, 8, 0};
    public static final int[] MAXRES = {90, 180, 40, 0};
    public static final boolean[] AUTO = {false, true, false, false};
    public static final int[] PELLETS = {1, 1, 8, 0};
    public static final float[] SPREAD = {0.5f, 1.3f, 5.5f, 0f};   // grados
    public static final float[] RELOAD = {1.3f, 2.0f, 2.4f, 0f};
    public static final float[] RANGE = {80f, 80f, 40f, 2.5f};
    public static final float[] KICK = {2.0f, 1.4f, 7.0f, 0f};     // retroceso de camara (grados)

    static final float SKIN_R = 0.74f, SKIN_G = 0.54f, SKIN_B = 0.43f;
    static final float SLV_R = 0.13f, SLV_G = 0.15f, SLV_B = 0.19f;

    /** Estado de animacion del arma en pantalla. */
    public static class View {
        public float bobX, bobY;
        public float recoil;      // 0..1
        public float reloadP = -1f; // 0..1 durante recarga, -1 si no
        public float swingP = -1f;  // 0..1 durante golpe de hacha
        public float raise = 1f;    // 0..1 al cambiar de arma
        public float flash;       // >0 destello de boca
        public float pump;        // 0..1 corredera/bombeo
    }

    static final Matrix4 m = new Matrix4();
    static final Matrix4 hm = new Matrix4();

    static void part(Matrix4 base, float ox, float oy, float oz, float sx, float sy, float sz,
                     float r, float g, float b, com.badlogic.gdx.graphics.Texture t) {
        Gfx.setTex(t);
        Gfx.setColor(r, g, b);
        Gfx.box(base, ox, oy, oz, sx, sy, sz);
    }

    static void partR(Matrix4 base, float ox, float oy, float oz, float rx, float ry, float rz,
                      float sx, float sy, float sz, float r, float g, float b, com.badlogic.gdx.graphics.Texture t) {
        Gfx.setTex(t);
        Gfx.setColor(r, g, b);
        Gfx.boxR(base, ox, oy, oz, rx, ry, rz, sx, sy, sz);
    }

    static void hand(Matrix4 base, float ox, float oy, float oz, float rx, float ry, float rz,
                     float len, Level L) {
        // mano + antebrazo con manga
        partR(base, ox, oy, oz, rx, ry, rz, 0.075f, 0.075f, 0.09f, SKIN_R, SKIN_G, SKIN_B, L.tGrain);
        hm.set(base).translate(ox, oy, oz);
        if (ry != 0f) hm.rotate(0, 1, 0, ry);
        if (rx != 0f) hm.rotate(1, 0, 0, rx);
        if (rz != 0f) hm.rotate(0, 0, 1, rz);
        part(hm, 0f, 0f, 0.05f + len / 2f, 0.085f, 0.085f, len, SLV_R, SLV_G, SLV_B, L.tGrain);
        part(hm, 0f, 0f, 0.05f + 0.02f, 0.09f, 0.09f, 0.04f, SKIN_R * 0.9f, SKIN_G * 0.9f, SKIN_B * 0.9f, L.tGrain);
    }

    static void flash(Matrix4 base, float x, float y, float z, float amt) {
        if (amt <= 0f) return;
        Gfx.setTex(null);
        Gfx.setColor(0f, 0f, 0f);
        Gfx.setEmis(1f, 0.85f, 0.45f);
        float s = 0.05f + 0.05f * amt;
        Gfx.boxR(base, x, y, z - 0.03f, 0, 0, 0, s, s, 0.08f);
        Gfx.boxR(base, x, y, z - 0.03f, 0, 0, 45, s * 2.2f, s * 0.35f, 0.02f);
        Gfx.boxR(base, x, y, z - 0.03f, 0, 0, -45, s * 2.2f, s * 0.35f, 0.02f);
        Gfx.setEmis(0f, 0f, 0f);
    }

    /** viewToWorld: inversa de la matriz de vista (convierte coordenadas de camara a mundo). */
    public static void draw(Matrix4 viewToWorld, int w, View v, Level L) {
        float px = 0.21f, py = -0.21f, pz = -0.45f;
        if (w == PISTOL) { px = 0.2f; py = -0.19f; pz = -0.40f; }
        if (w == AXE) { px = 0.26f; py = -0.42f; pz = -0.52f; }

        float rx = 0f, rz = 0f, ry = 0f;
        // retroceso
        pz += v.recoil * (w == SHOTGUN ? 0.09f : 0.045f);
        rx += v.recoil * (w == SHOTGUN ? 9f : 4f);
        // bamboleo al caminar
        px += v.bobX;
        py += v.bobY;
        // subir arma
        float up = 1f - Util.clamp(v.raise, 0f, 1f);
        py -= up * 0.45f;
        rx -= up * 25f;
        // recarga
        if (v.reloadP >= 0f) {
            float s = (float) Math.sin(v.reloadP * Math.PI);
            py -= s * 0.22f;
            rx -= s * 35f;
            rz += s * 18f;
            px -= s * 0.04f;
        }
        // golpe de hacha
        if (w == AXE && v.swingP >= 0f) {
            float p = v.swingP;
            float e = p < 0.3f ? (p / 0.3f) * 0.25f : 0.25f + (p - 0.3f) / 0.7f * 0.75f; // anticipacion lenta, golpe rapido
            float a = Util.lerp(40f, -85f, e);
            rz = a;
            px += Util.lerp(0.12f, -0.30f, e);
            pz -= (float) Math.sin(p * Math.PI) * 0.16f;
            rx -= (float) Math.sin(p * Math.PI) * 25f;
            py += (float) Math.sin(p * Math.PI) * 0.06f;
        }

        m.set(viewToWorld).translate(px, py, pz);
        if (ry != 0f) m.rotate(0, 1, 0, ry);
        if (rx != 0f) m.rotate(1, 0, 0, rx);
        if (rz != 0f) m.rotate(0, 0, 1, rz);

        Level l = L;
        com.badlogic.gdx.graphics.Texture met = l.tMetal, wod = l.tWood, gr = l.tGrain;
        Gfx.setEmis(0f, 0f, 0f);

        switch (w) {
            case PISTOL: {
                float slide = v.recoil * 0.05f;
                part(m, 0f, 0.03f, -0.1f + slide, 0.045f, 0.055f, 0.26f, 0.35f, 0.35f, 0.38f, met);
                part(m, 0f, -0.012f, -0.07f, 0.04f, 0.04f, 0.2f, 0.12f, 0.12f, 0.13f, met);
                partR(m, 0f, -0.09f, 0.02f, -12f, 0f, 0f, 0.042f, 0.12f, 0.065f, 0.07f, 0.07f, 0.075f, gr);
                part(m, 0f, 0.03f, -0.235f, 0.022f, 0.022f, 0.03f, 0.08f, 0.08f, 0.09f, met);
                part(m, 0f, 0.064f, -0.2f, 0.01f, 0.012f, 0.01f, 0.9f, 0.9f, 0.9f, null);
                part(m, 0f, 0.064f, 0.02f, 0.016f, 0.012f, 0.012f, 0.9f, 0.9f, 0.9f, null);
                part(m, 0f, -0.05f, -0.04f, 0.012f, 0.02f, 0.07f, 0.08f, 0.08f, 0.09f, met);
                hand(m, 0.005f, -0.1f, 0.03f, 18f, 0f, 0f, 0.3f, l);
                hand(m, -0.035f, -0.11f, -0.01f, 22f, -14f, 0f, 0.3f, l);
                flash(m, 0f, 0.03f, -0.255f, v.flash);
                break;
            }
            case AK: {
                part(m, 0f, 0f, -0.15f, 0.06f, 0.08f, 0.35f, 0.16f, 0.16f, 0.17f, met);
                part(m, 0f, 0.045f, -0.15f, 0.058f, 0.016f, 0.32f, 0.2f, 0.2f, 0.21f, met);
                part(m, 0f, 0.012f, -0.58f, 0.022f, 0.022f, 0.52f, 0.1f, 0.1f, 0.11f, met);
                part(m, 0f, 0.052f, -0.5f, 0.03f, 0.024f, 0.3f, 0.18f, 0.18f, 0.19f, met);
                part(m, 0f, -0.012f, -0.4f, 0.068f, 0.06f, 0.26f, 0.62f, 0.4f, 0.22f, wod);
                part(m, 0f, 0.052f, -0.82f, 0.012f, 0.045f, 0.012f, 0.1f, 0.1f, 0.1f, met);
                partR(m, 0f, -0.025f, 0.2f, -4f, 0f, 0f, 0.046f, 0.095f, 0.3f, 0.62f, 0.4f, 0.22f, wod);
                partR(m, 0f, -0.1f, 0.01f, 22f, 0f, 0f, 0.042f, 0.11f, 0.055f, 0.62f, 0.4f, 0.22f, wod);
                partR(m, 0f, -0.14f, -0.15f, 12f, 0f, 0f, 0.04f, 0.2f, 0.075f, 0.09f, 0.09f, 0.1f, met);
                part(m, 0f, -0.055f, -0.1f, 0.012f, 0.025f, 0.08f, 0.1f, 0.1f, 0.11f, met);
                hand(m, 0.005f, -0.105f, 0.03f, 20f, 0f, 0f, 0.32f, l);
                hand(m, -0.01f, -0.06f, -0.4f, 8f, -12f, 0f, 0.4f, l);
                flash(m, 0f, 0.012f, -0.85f, v.flash);
                break;
            }
            case SHOTGUN: {
                float pump = (float) Math.sin(Util.clamp(v.pump, 0f, 1f) * Math.PI) * 0.12f;
                part(m, 0f, 0f, -0.1f, 0.062f, 0.085f, 0.3f, 0.13f, 0.13f, 0.14f, met);
                part(m, 0f, 0.028f, -0.55f, 0.032f, 0.032f, 0.72f, 0.1f, 0.1f, 0.11f, met);
                part(m, 0f, -0.015f, -0.55f, 0.03f, 0.03f, 0.62f, 0.25f, 0.25f, 0.27f, met);
                part(m, 0f, -0.018f, -0.44f + pump, 0.07f, 0.058f, 0.22f, 0.45f, 0.28f, 0.15f, wod);
                partR(m, 0f, -0.035f, 0.2f, -5f, 0f, 0f, 0.052f, 0.105f, 0.36f, 0.45f, 0.28f, 0.15f, wod);
                partR(m, 0f, -0.09f, 0.06f, 20f, 0f, 0f, 0.042f, 0.1f, 0.05f, 0.45f, 0.28f, 0.15f, wod);
                part(m, 0f, 0.052f, -0.9f, 0.01f, 0.012f, 0.01f, 0.9f, 0.85f, 0.6f, null);
                hand(m, 0.005f, -0.1f, 0.05f, 20f, 0f, 0f, 0.32f, l);
                hand(m, -0.01f, -0.06f, -0.44f + pump, 8f, -12f, 0f, 0.45f, l);
                flash(m, 0f, 0.028f, -0.93f, v.flash * 1.6f);
                break;
            }
            default: { // hacha de bombero
                partR(m, 0f, 0.28f, 0f, -12f, 0f, 0f, 0.036f, 0.7f, 0.036f, 0.5f, 0.32f, 0.17f, wod);
                partR(m, 0f, 0.62f, -0.1f, -12f, 0f, 0f, 0.045f, 0.15f, 0.2f, 0.4f, 0.4f, 0.44f, met);
                partR(m, 0f, 0.62f, -0.215f, -12f, 0f, 0f, 0.012f, 0.19f, 0.05f, 0.8f, 0.8f, 0.85f, met);
                partR(m, 0f, 0.62f, 0.03f, -12f, 0f, 0f, 0.04f, 0.07f, 0.09f, 0.3f, 0.3f, 0.33f, met);
                partR(m, 0f, 0.0f, 0.01f, -12f, 0f, 0f, 0.04f, 0.1f, 0.04f, 0.6f, 0.05f, 0.05f, gr); // empunadura roja
                hand(m, 0f, 0.0f, 0.02f, 10f, 0f, 0f, 0.35f, l);
                hand(m, 0f, 0.14f, 0.0f, 10f, 10f, 0f, 0.3f, l);
                break;
            }
        }
    }
}
