package com.jhon.test;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.InputAdapter;
import com.badlogic.gdx.graphics.Color;
import com.badlogic.gdx.graphics.GL20;
import com.badlogic.gdx.graphics.OrthographicCamera;
import com.badlogic.gdx.graphics.g2d.BitmapFont;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.graphics.glutils.ShapeRenderer;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.utils.Align;

/** Controles tactiles (joystick flotante + botones + mirada libre) y HUD. Espacio virtual: alto = 720. */
public class Hud extends InputAdapter {
    static final float H = 720f;
    static final int B_FIRE = 0, B_JUMP = 1, B_RELOAD = 2, B_USE = 3, B_FLASH = 4, B_SLOT0 = 5, NB = 9;

    final Game g;
    final OrthographicCamera cam = new OrthographicCamera();
    final ShapeRenderer sr = new ShapeRenderer();
    final SpriteBatch sb = new SpriteBatch();
    final BitmapFont font = new BitmapFont();
    float W = 1280f, scale = 1f;

    // botones
    final float[] bx = new float[NB], by = new float[NB], br = new float[NB];
    final String[] bl = {"FUEGO", "SALTO", "RECARGA", "USAR", "LUZ", "1", "2", "3", "4"};
    final int[] held = new int[NB];

    // punteros
    static final int MAXP = 10;
    final int[] role = new int[MAXP];       // 0 nada, 1 joystick, 2 mirada, 3 boton
    final int[] ptrBtn = new int[MAXP];
    final float[] lastX = new float[MAXP], lastY = new float[MAXP];
    int movePtr = -1;
    float mbx, mby, mcx, mcy;

    // salidas para el juego
    public float moveX, moveY, lookDX, lookDY;
    public boolean jumpEdge, reloadEdge, useEdge, flashEdge, tapEdge;
    public int slotEdge = -1;

    final Color tmp = new Color();
    Texture pix;

    public Hud(Game g) {
        this.g = g;
        font.getRegion().getTexture().setFilter(Texture.TextureFilter.Linear, Texture.TextureFilter.Linear);
        layout();
    }

    public boolean fireHeld() { return held[B_FIRE] > 0; }

    public void layout() {
        scale = Gdx.graphics.getHeight() / H;
        W = Gdx.graphics.getWidth() / scale;
        cam.setToOrtho(false, W, H);
        bx[B_FIRE] = W - 170f; by[B_FIRE] = 150f; br[B_FIRE] = 92f;
        bx[B_JUMP] = W - 70f; by[B_JUMP] = 330f; br[B_JUMP] = 48f;
        bx[B_RELOAD] = W - 320f; by[B_RELOAD] = 95f; br[B_RELOAD] = 48f;
        bx[B_USE] = W - 340f; by[B_USE] = 250f; br[B_USE] = 50f;
        bx[B_FLASH] = W - 70f; by[B_FLASH] = 440f; br[B_FLASH] = 36f;
        for (int i = 0; i < 4; i++) { bx[B_SLOT0 + i] = W - 300f + i * 72f; by[B_SLOT0 + i] = H - 50f; br[B_SLOT0 + i] = 31f; }
    }

    int hit(float vx, float vy) {
        for (int i = 0; i < NB; i++) {
            float dx = vx - bx[i], dy = vy - by[i];
            float r = br[i] + 8f;
            if (dx * dx + dy * dy <= r * r) return i;
        }
        return -1;
    }

    // ------------------------------------------------------------------ entrada

    @Override
    public boolean touchDown(int sx, int sy, int p, int button) {
        if (p >= MAXP) return false;
        float vx = sx / scale, vy = H - sy / scale;
        tapEdge = true;
        int b = hit(vx, vy);
        if (b >= 0) {
            role[p] = 3;
            ptrBtn[p] = b;
            held[b]++;
            if (b == B_JUMP) jumpEdge = true;
            if (b == B_RELOAD) reloadEdge = true;
            if (b == B_USE) useEdge = true;
            if (b == B_FLASH) flashEdge = true;
            if (b >= B_SLOT0) slotEdge = b - B_SLOT0;
            return true;
        }
        if (vx < W * 0.42f && movePtr < 0) {
            movePtr = p;
            role[p] = 1;
            mbx = vx; mby = vy; mcx = vx; mcy = vy;
            return true;
        }
        role[p] = 2;
        lastX[p] = sx; lastY[p] = sy;
        return true;
    }

    @Override
    public boolean touchDragged(int sx, int sy, int p) {
        if (p >= MAXP) return false;
        if (role[p] == 1) {
            mcx = sx / scale;
            mcy = H - sy / scale;
            float dx = mcx - mbx, dy = mcy - mby;
            float len = (float) Math.sqrt(dx * dx + dy * dy);
            if (len > 130f) { mbx += dx / len * (len - 130f); mby += dy / len * (len - 130f); } // el joystick sigue al dedo
        } else if (role[p] == 2) {
            lookDX += (sx - lastX[p]) / scale;
            lookDY += (sy - lastY[p]) / scale;
            lastX[p] = sx; lastY[p] = sy;
        }
        return true;
    }

    @Override
    public boolean touchUp(int sx, int sy, int p, int button) {
        if (p >= MAXP) return false;
        if (role[p] == 3 && held[ptrBtn[p]] > 0) held[ptrBtn[p]]--;
        if (role[p] == 1) { movePtr = -1; moveX = 0f; moveY = 0f; }
        role[p] = 0;
        return true;
    }

    /** Llamar una vez por frame antes de leer las salidas. */
    public void poll() {
        if (movePtr >= 0) {
            float R = 95f;
            float dx = (mcx - mbx) / R, dy = (mcy - mby) / R;
            float len = (float) Math.sqrt(dx * dx + dy * dy);
            if (len > 1f) { dx /= len; dy /= len; len = 1f; }
            if (len < 0.12f) { dx = 0f; dy = 0f; }
            moveX = dx; moveY = dy;
        } else {
            moveX = 0f; moveY = 0f;
        }
    }

    public void endFrame() {
        lookDX = 0f; lookDY = 0f;
        jumpEdge = false; reloadEdge = false; useEdge = false; flashEdge = false; tapEdge = false;
        slotEdge = -1;
    }

    // ------------------------------------------------------------------ dibujo

    void txt(String s, float x, float y, float size, float r, float gg, float b, float a, int align) {
        font.getData().setScale(size);
        font.setColor(0f, 0f, 0f, a * 0.8f);
        float w = 1000f;
        float ox = align == Align.center ? x - w / 2 : (align == Align.right ? x - w : x);
        font.draw(sb, s, ox + 1.5f, y - 1.5f, w, align, false);
        font.setColor(r, gg, b, a);
        font.draw(sb, s, ox, y, w, align, false);
    }

    void edge(float x, float y, float w, float h, int dir, float a) {
        // degradado rojo desde el borde: dir 0 abajo, 1 arriba, 2 izquierda, 3 derecha
        Color c = tmp.set(0.8f, 0f, 0f, a);
        Color z = new Color(0.8f, 0f, 0f, 0f);
        if (dir == 0) sr.rect(x, y, w, h, c, c, z, z);
        else if (dir == 1) sr.rect(x, y, w, h, z, z, c, c);
        else if (dir == 2) sr.rect(x, y, w, h, c, z, z, c);
        else sr.rect(x, y, w, h, z, c, c, z);
    }

    public void draw() {
        Player p = g.player;
        Gdx.gl.glEnable(GL20.GL_BLEND);
        Gdx.gl.glBlendFunc(GL20.GL_SRC_ALPHA, GL20.GL_ONE_MINUS_SRC_ALPHA);
        Gdx.gl.glDisable(GL20.GL_DEPTH_TEST);
        sr.setProjectionMatrix(cam.combined);
        sb.setProjectionMatrix(cam.combined);

        boolean intro = g.state == Game.INTRO;
        float cx = W / 2f;

        sr.begin(ShapeRenderer.ShapeType.Filled);
        // viñeta de dano
        float va = Math.min(0.75f, p.hurtT * 1.4f);
        if (p.hp < 30f && !p.dead) va = Math.max(va, 0.25f + 0.15f * (float) Math.sin(g.time * 6f));
        if (va > 0.01f && !intro) {
            edge(0, 0, W, 150, 0, va);
            edge(0, H - 150, W, 150, 1, va);
            edge(0, 0, 200, H, 2, va);
            edge(W - 200, 0, 200, H, 3, va);
        }
        if (intro) {
            sr.setColor(0f, 0f, 0f, 1f);
            float bar = 85f;
            sr.rect(0, 0, W, bar);
            sr.rect(0, H - bar, W, bar);
        } else {
            // mira
            float sp = 7f + p.heat * 14f + (p.recoil * 8f);
            if (p.cur != Weapons.AXE) {
                sr.setColor(1f, 1f, 1f, 0.8f);
                sr.rect(cx - sp - 10f, H / 2 - 1f, 10f, 2f);
                sr.rect(cx + sp, H / 2 - 1f, 10f, 2f);
                sr.rect(cx - 1f, H / 2 - sp - 10f, 2f, 10f);
                sr.rect(cx - 1f, H / 2 + sp, 2f, 10f);
            } else {
                sr.setColor(1f, 1f, 1f, 0.7f);
                sr.circle(cx, H / 2, 3f, 8);
            }
            if (p.hitMarker > 0f) {
                sr.setColor(1f, 0.2f, 0.2f, Math.min(1f, p.hitMarker * 5f));
                sr.rectLine(cx - 14, H / 2 - 14, cx - 6, H / 2 - 6, 2.5f);
                sr.rectLine(cx + 14, H / 2 - 14, cx + 6, H / 2 - 6, 2.5f);
                sr.rectLine(cx - 14, H / 2 + 14, cx - 6, H / 2 + 6, 2.5f);
                sr.rectLine(cx + 14, H / 2 + 14, cx + 6, H / 2 + 6, 2.5f);
            }
            // barra de vida
            float hp = Util.clamp(p.hp / 100f, 0f, 1f);
            sr.setColor(0f, 0f, 0f, 0.55f);
            sr.rect(28, H - 66, 324, 30);
            sr.setColor(1f - hp * 0.8f, 0.25f + hp * 0.6f, 0.1f, 0.95f);
            sr.rect(32, H - 62, 316f * hp, 22);

            // controles
            if (movePtr >= 0) {
                sr.setColor(1f, 1f, 1f, 0.12f);
                sr.circle(mbx, mby, 95f, 32);
                sr.setColor(1f, 1f, 1f, 0.35f);
                float dx = mcx - mbx, dy = mcy - mby;
                float len = (float) Math.sqrt(dx * dx + dy * dy);
                if (len > 95f) { dx = dx / len * 95f; dy = dy / len * 95f; }
                sr.circle(mbx + dx, mby + dy, 42f, 24);
            } else {
                sr.setColor(1f, 1f, 1f, 0.07f);
                sr.circle(170f, 170f, 95f, 32);
            }
            for (int i = 0; i < NB; i++) {
                boolean slot = i >= B_SLOT0;
                float a = held[i] > 0 ? 0.45f : 0.2f;
                sr.setColor(1f, 1f, 1f, a);
                if (slot) {
                    int w = i - B_SLOT0;
                    if (!p.has[w]) sr.setColor(1f, 1f, 1f, 0.07f);
                    if (p.cur == w) sr.setColor(1f, 0.8f, 0.2f, 0.5f);
                }
                if (i == B_FIRE) sr.setColor(1f, 0.3f, 0.2f, held[i] > 0 ? 0.55f : 0.28f);
                sr.circle(bx[i], by[i], br[i], 28);
            }
            // aviso de municion baja / recarga
            if (p.reloading) {
                sr.setColor(1f, 1f, 1f, 0.6f);
                float prog = 1f - p.reloadT / Weapons.RELOAD[p.cur];
                sr.rect(cx - 80f, 150f, 160f * Util.clamp(prog, 0f, 1f), 6f);
            }
        }
        // fundido
        if (g.fade > 0.001f) {
            sr.setColor(0f, 0f, 0f, g.fade);
            sr.rect(0, 0, W, H);
        }
        if (g.state == Game.DEAD) {
            sr.setColor(0.35f, 0f, 0f, Math.min(0.7f, g.stateT * 0.5f));
            sr.rect(0, 0, W, H);
        }
        if (g.state == Game.WIN) {
            sr.setColor(0f, 0f, 0f, Math.min(0.6f, g.stateT * 0.4f));
            sr.rect(0, 0, W, H);
        }
        sr.end();

        sb.begin();
        if (!intro) {
            txt("JHON", 36, H - 70, 1.3f, 1f, 1f, 1f, 1f, Align.left);
            txt(Math.max(0, (int) Math.ceil(p.hp)) + "", 330, H - 40, 1.2f, 1f, 1f, 1f, 1f, Align.right);
            // municion
            if (p.cur == Weapons.AXE) {
                txt(Weapons.NAME[p.cur], cx, 70, 1.5f, 1f, 1f, 1f, 1f, Align.center);
            } else {
                txt(Weapons.NAME[p.cur], cx, 100, 1.2f, 0.85f, 0.85f, 0.85f, 1f, Align.center);
                boolean low = p.mag[p.cur] <= Weapons.MAG[p.cur] / 4;
                txt(p.mag[p.cur] + " / " + p.res[p.cur], cx, 60, 1.8f, 1f, low ? 0.4f : 1f, low ? 0.3f : 1f, 1f, Align.center);
            }
            for (int i = 0; i < NB; i++) {
                String s = bl[i];
                float sz = i == B_FIRE ? 1.3f : (i >= B_SLOT0 ? 1.1f : 0.8f);
                if (i >= B_SLOT0) s = new String[]{"P", "AK", "ES", "HA"}[i - B_SLOT0];
                txt(s, bx[i], by[i] + 8f * sz, sz, 1f, 1f, 1f, 0.9f, Align.center);
            }
            // objetivo
            if (g.objective != null) {
                txt(g.objective, cx, H - 24, 1.25f, 1f, 0.9f, 0.5f, 1f, Align.center);
            }
            if (g.hordeLeft >= 0f) {
                txt("ALARMA ACTIVA - " + (int) Math.ceil(g.hordeLeft) + " s", cx, H - 56, 1.2f, 1f, 0.3f, 0.25f, 1f, Align.center);
            }
            if (g.prompt != null) txt(g.prompt, cx, H / 2 - 90f, 1.4f, 1f, 1f, 0.7f, 1f, Align.center);
            if (g.messageT > 0f) txt(g.message, cx, H / 2 + 130f, 1.4f, 0.8f, 1f, 0.8f, Math.min(1f, g.messageT), Align.center);
            txt("ZOMBIS: " + g.aliveCount() + "   BAJAS: " + g.kills, 36, H - 90, 0.9f, 0.8f, 0.8f, 0.8f, 0.9f, Align.left);
        }
        if (g.subtitle != null) {
            txt(g.subtitleWho, cx, intro ? 62f : 230f, 1.0f, 1f, 0.8f, 0.3f, 1f, Align.center);
            txt(g.subtitle, cx, intro ? 36f : 205f, 1.3f, 1f, 1f, 1f, 1f, Align.center);
        }
        if (intro && g.introT > 3f) txt("Toca para saltar", W - 30f, 36f, 0.9f, 0.8f, 0.8f, 0.8f, 0.8f, Align.right);
        if (g.state == Game.DEAD && g.stateT > 1f) {
            txt("HAS MUERTO", cx, H / 2 + 60f, 3f, 1f, 0.2f, 0.15f, 1f, Align.center);
            txt("Toca para reintentar", cx, H / 2 - 20f, 1.4f, 1f, 1f, 1f, 1f, Align.center);
        }
        if (g.state == Game.WIN && g.stateT > 0.8f) {
            txt("RESCATADO", cx, H / 2 + 70f, 3f, 0.5f, 1f, 0.5f, 1f, Align.center);
            txt("Bajas: " + g.kills + "   Tiempo: " + (int) g.playTime + " s", cx, H / 2 - 5f, 1.4f, 1f, 1f, 1f, 1f, Align.center);
            txt("Prueba superada. Toca para jugar de nuevo", cx, H / 2 - 55f, 1.2f, 0.9f, 0.9f, 0.9f, 1f, Align.center);
        }
        sb.end();
    }

    public void dispose() {
        sr.dispose();
        sb.dispose();
        font.dispose();
    }
}
